package com.rabbit.publisher;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;
import com.rabbit.publisher.Client;
@Component
@RefreshScope
public class Publisher {
	 @Autowired
	   private AmqpTemplate rabbitTemplate;
	   
	   //@Value("${jsa.rabbitmq.exchange}")
	   private String exchange="directRDP";
	   
	   //@Value("${jsa.rabbitmq.routingkey}")
	   private String routingKey="routingkeyRDP";
	   @Value("${spring.main.allow-bean-definition-overriding}")
	   private String overriding;
	   public void produceMsg(String msg){
		   Client client=new Client();
		   client.setIp("localhost");
		   client.setPort("9090");
		   rabbitTemplate.convertAndSend(exchange, routingKey, client);
	      System.out.println("Send msg = " + msg);
	      System.out.println("overriding value ====>>"+overriding);
	   }
}
