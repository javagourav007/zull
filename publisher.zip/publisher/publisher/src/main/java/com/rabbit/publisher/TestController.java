package com.rabbit.publisher;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RefreshScope
@RestController
public class TestController {
	 @Autowired
	   Publisher publisher;
	 
	   @GetMapping("/send")
	   public String sendMessage(@RequestParam("msg") String msg){
	      System.out.println("*****"+msg);
	      publisher.produceMsg("");
	      return "Successfully Msg Sent";
	   }
	   
	   @GetMapping("/emlpoyee/{employeeId}")
	   public Employee getEmployeeById(@PathVariable("employeeId") String employeeId){
		   Employee employee=new Employee();
		   employee.setEmployeeId(employeeId);
		   employee.setEmployeeDesignation("TeamLead");
		   employee.setEmployeeName("Zenith");
	      return employee;
	   }
}
