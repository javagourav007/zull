package com.rabbit.publisher;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PublisherApplicationTests {

	@Test
	public void getEmployeeDetails() throws Exception {
		RestTemplate restTemplate=new RestTemplate();
		
		//Employee employee=restTemplate.getForEntity("http://localhost:9090/emlpoyee/A151564", Employee.class);
		ResponseEntity<Employee> employee=restTemplate.post
				//getForEntity("http://localhost:9090/emlpoyee/A151564", Employee.class);
		
		assertThat(employee.getBody().getEmployeeName(), equalTo("Zenith"));
		assertThat(employee.getBody().getEmployeeDesignation(), equalTo("TeamLead"));
	}

}
