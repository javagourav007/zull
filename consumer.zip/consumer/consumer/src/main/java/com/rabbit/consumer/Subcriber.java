package com.rabbit.consumer;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;
@Component
public class Subcriber {
	@RabbitListener(queues = "queueRDP",containerFactory="jsaFactory")
	public void recievedMessage(Client client) {
		System.out.println("Recieved Message From RabbitMQ: " + client.getIp()+" port==>>"+client.getPort());
	}
}
