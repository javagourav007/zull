package com.rci.apis.member.balance.test;

import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import brave.Span;
import brave.Tracer;
import brave.propagation.TraceContext;

/**
 * Member Balance JUnit Test
 *  
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class BalanceControllerTest {
	
	private MockMvc mockMvc;	
		
	@Autowired
	private WebApplicationContext webApplicationContext;
	
	@MockBean
	private Tracer tracer;
	
	@MockBean
	private Span span;
	
	private TraceContext context;
	

	@Before
	public void setUp() {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	    context = TraceContext.newBuilder().traceId(1).spanId(3).build();
		when(tracer.currentSpan()).thenReturn(span);
		when(span.context()).thenReturn(context);
	}
	
	/**
	 * This method will test if Balance Info is getting retrieved or not
	 * 
	 * @throws Exception the exception.
	 */
	@Test
	public void testBalanceForValidMemberForPoints() throws Exception {

		mockMvc
				.perform(MockMvcRequestBuilders.get("/points/96538008/balance")
						.header("ConsumerChannel", "Web")
						.header("OperatorId", "TMA0S2V")
						.header("MemberType", "POINTS")
						.param("membershipType", "FAIR")
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk()).andReturn().getResponse().getContentAsString();
	}
	
	/**
	 * This method will test to get Balance Info without ConsumerChannel in the Request header.
	 *
	 * @throws Exception the exception.
	 */
	@Test
	public void testGetBalanceInfoWithoutConsumerChannel() throws Exception {

		mockMvc
				.perform(MockMvcRequestBuilders.get("/points/96538008/balance")
						.header("ConsumerChannel", "")
						.header("OperatorId", "TMA0S2V")
						.header("member-type", "POINTS")
						.param("membershipType", "FAIR")
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isBadRequest()).andReturn().getResponse().getContentAsString();

	}
	
	/**
	 * This method will test to get Balance Info without OperatorId in the Request header.
	 *
	 * @throws Exception the exception.
	 */
	@Test
	public void testGetBalanceInfoWithoutOperatorId() throws Exception {

		mockMvc
				.perform(MockMvcRequestBuilders.get("/points/96538008/balance")
						.header("ConsumerChannel", "Web")
						.header("OperatorId", "")
						.header("member-type", "POINTS")
						.param("membershipType", "FAIR")
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isBadRequest()).andReturn().getResponse().getContentAsString();

	}
	
	/**
	 * This method will test to get Balance Info without member id in the URL.
	 *
	 * @throws Exception the exception.
	 */
	@Test
	public void testGetBalanceInfoWithoutMemberId() throws Exception {

		mockMvc
				.perform(MockMvcRequestBuilders.get("/points/ /balance")
						.header("ConsumerChannel", "Web")
						.header("OperatorId", "TMA0S2V")
						.header("member-type", "POINTS")
						.param("membershipType", "FAIR")
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isBadRequest()).andReturn().getResponse().getContentAsString();

	}

}
