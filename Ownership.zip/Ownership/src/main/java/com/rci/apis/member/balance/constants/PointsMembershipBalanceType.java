package com.rci.apis.member.balance.constants;

public enum PointsMembershipBalanceType {
	RCI_POINTS_TYPE,CLUB_POINTS_TYPE
}
