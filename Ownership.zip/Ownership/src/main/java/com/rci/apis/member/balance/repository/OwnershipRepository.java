package com.rci.apis.member.balance.repository;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.rci.apis.member.balance.entity.ResortEntity;

@Repository
public interface OwnershipRepository extends JpaRepository<ResortEntity,String> {
	
	@Query(value="SELECT DISTINCT RESORT_ID, RESORT_NAME, AFFILIATE_CODE FROM DBL_POINT_RESORT  WHERE AFFILIATE_CODE=:affiliatedCode",nativeQuery=true)
	public Optional<List<ResortEntity>> findAffiliatedHGByAffCode(@Param("affiliatedCode") String affiliatedCode);										
}
