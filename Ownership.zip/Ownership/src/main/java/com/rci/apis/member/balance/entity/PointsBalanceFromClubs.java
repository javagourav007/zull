package com.rci.apis.member.balance.entity;

import java.io.Serializable;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PointsBalanceFromClubs implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private String memberID;
	
	private long currentYearBalance;
	private long nextYearBalance;
	private long thirdYearBalance;

	private LocalDate currentYearStartDate;
	private LocalDate nextYearStartDate;
	private LocalDate thirdYearStartDate;

	private LocalDate currentYearEndDate;
	private LocalDate nextYearEndDate;
	private LocalDate thirdYearEndDate;

}
