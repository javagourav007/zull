package com.rci.apis.member.balance.service;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rci.apis.member.balance.entity.MembershipInfo;
import com.rci.apis.member.balance.entity.PointsMembershipSummary;
import com.rci.apis.member.balance.entity.SynergexMemberInfoSummary;
import com.rci.apis.member.balance.entity.SynergexMemberProfile;
import com.rci.apis.member.balance.entity.SynergexPointsInquiry;
import com.rci.apis.member.balance.mapper.PointsMembershipSummaryMapper;
import com.rci.apis.member.balance.proxy.MembershipServiceProxy;
import com.rci.apis.member.balance.proxy.SynergexServiceProxy;
import com.rci.service.common.model.ConsumerChannel;
import com.rci.service.common.model.MemberType;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 *  ClubCustomerAccountSummaryServiceImpl class provides the service methods for 
 *  fetching customer account summary information for CWP.
 */
@Getter
@Setter
@Slf4j
@Service
public class ClubCustomerAccountSummaryService {
	
	/** Proxy for Synergex gateway service */
	@Autowired
	protected SynergexServiceProxy serviceProxy;
	
	/** Proxy for Membership service */
	@Autowired
	protected MembershipServiceProxy membershipServiceProxy;
	
	/** PointsMembershipSummaryMapper ptsMembershipDetailsMapper */
	@Autowired
	protected PointsMembershipSummaryMapper ptsMembershipDetailsMapper;
	
	/**
	 * Calculate customer account summary Info for a CWP Member.
	 * @param memberId  The unique identifier for the member
	 * @param consumerChannel  The ConsumerChannel
	 * @param operatorId Unique identifier for the Operator
	 * @param startDate The start date
	 * @param membershipSubType Membership Sub Type for the member
	 * @return PointsMembershipSummary - Customer Account Summary Information for the CWP Member
	 */
	public PointsMembershipSummary getMbrPtsMembershipDetails(String memberId, ConsumerChannel consumerChannel,
			String operatorId, LocalDate startDate, MemberType memberType) {
		
		log.debug("Entering into getMbrPtsMembershipDetails method");
		
		SynergexPointsInquiry synergexPointsInquiryDetails = null;
		SynergexMemberInfoSummary synergexMemberInfoSummary = null;
		SynergexMemberProfile synergexMemberProfile = null;
		String membershipSubType = null;
		
		if(null == startDate){
			startDate = LocalDate.now();
		}
		
		MembershipInfo membership = membershipServiceProxy.
				getMembershipDetails(consumerChannel, memberType, operatorId, memberId);
		
		if (null != membership && null != membership.getMembershipSubType()) {
			membershipSubType = membership.getMembershipSubType();
		}
		
		log.debug("Invoking Synergex API Gateway GetPointsInquiry");
		
		synergexPointsInquiryDetails = serviceProxy.
				getPointsInquiry(memberId, operatorId, consumerChannel, startDate, membershipSubType);
		
		log.debug("Received response from Synergex API Gateway GetPointsInquiry:{}", synergexPointsInquiryDetails);
		
		log.debug("Invoking Synergex API Gateway GetMemberInfoSummary");
		
		synergexMemberInfoSummary = serviceProxy.getMemberInfoSummary(memberId, operatorId, consumerChannel);

		log.debug("Received response from Synergex API Gateway GetMemberInfoSummary:{}", synergexMemberInfoSummary);
		
		log.debug("Invoking Synergex API Gateway GetMemberProfile");
		
		synergexMemberProfile = serviceProxy.getMemberProfile(memberId, operatorId, consumerChannel);

		log.debug("Received response from Synergex API Gateway GetMemberProfile:{}", synergexMemberProfile);

		log.debug("Exiting from getMbrPtsMembershipDetails method");
		
		return ptsMembershipDetailsMapper.map
				(memberId,synergexPointsInquiryDetails,synergexMemberInfoSummary,synergexMemberProfile);
	}
}
