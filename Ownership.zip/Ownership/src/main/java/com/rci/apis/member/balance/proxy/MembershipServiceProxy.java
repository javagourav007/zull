package com.rci.apis.member.balance.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

import com.rci.apis.member.balance.entity.MembershipInfo;
import com.rci.service.common.model.ConsumerChannel;
import com.rci.service.common.model.MemberType;

@FeignClient(name = "main-rci-member-membership-service", url="${proxy.url}")
public interface MembershipServiceProxy {
	
	@GetMapping(value = { "/members/{customer-id}/membership/details" }, produces = { MediaType.APPLICATION_JSON_VALUE })
	MembershipInfo getMembershipDetails(
			@RequestHeader(value = "ConsumerChannel", required = true) ConsumerChannel consumerChannel,
			@RequestHeader(value = "MemberType", required = true)MemberType memberType,
			@RequestHeader(value = "OperatorId", required = true)String operatorId,
			@PathVariable(value = "customer-id", required = true)String customerId);

}
