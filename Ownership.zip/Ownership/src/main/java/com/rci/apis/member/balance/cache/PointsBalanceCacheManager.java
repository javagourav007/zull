package com.rci.apis.member.balance.cache;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.rci.apis.member.balance.config.RedisCacheConfig;
import com.rci.apis.member.balance.entity.PointsBalanceFromClubs;
import com.rci.apis.member.balance.mapper.PointsMembershipBalanceFromClubsMapper;
import com.rci.apis.member.balance.model.PointsMembershipBalanceFromClubs;
import com.rci.service.common.model.Status;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class PointsBalanceCacheManager{
	
	/** PointsMembershipBalanceFromClubsMapper ptsMembershipBalanceFromClubsMapper */
	@Autowired
	protected PointsMembershipBalanceFromClubsMapper ptsMembershipBalanceFromClubsMapper;
	
	@Cacheable(value = RedisCacheConfig.POINTS_BALANCE_CACHE, key="#ptsMembershipBalanceFromClubs.memberID", cacheManager = RedisCacheConfig.POINTS_BALANCE_CACHE_MANAGER)
	public PointsBalanceFromClubs getPtsMembershipDetailsClubs(PointsBalanceFromClubs ptsMembershipBalanceFromClubs) {

		log.debug("Inside getPtsMembershipDetailsClubs() method");
		
		return ptsMembershipBalanceFromClubs;

	}
	
	@CachePut(value = RedisCacheConfig.POINTS_BALANCE_CACHE, key="#ptsMembershipBalanceFromClubs.memberID", cacheManager = RedisCacheConfig.POINTS_BALANCE_CACHE_MANAGER)
	public PointsBalanceFromClubs populatePtsMembershipDetailsClubs(PointsMembershipBalanceFromClubs ptsMembershipBalanceFromClubs) {

		log.debug("Inside populatePtsMembershipDetailsClubs() method");
		
		return ptsMembershipBalanceFromClubsMapper.map
				(ptsMembershipBalanceFromClubs);

	}
	
	@CacheEvict(value = RedisCacheConfig.POINTS_BALANCE_CACHE, key = "#cacheKey", cacheManager = RedisCacheConfig.POINTS_BALANCE_CACHE_MANAGER)
	public Status clearPtsMemberBalanceClubsCache(String cacheKey) {
		
		log.debug("Inside clearPtsMemberBalanceClubsCache() method");
		
		Status status = new Status();
		status.setStatus(true);
		return status;

	}	
}
