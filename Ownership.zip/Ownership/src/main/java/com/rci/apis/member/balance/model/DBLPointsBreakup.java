package com.rci.apis.member.balance.model;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModel;
import lombok.Data;

/**
 * DBL Points Breakup Information.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@ApiModel("DBL Points Breakup Details")
public class DBLPointsBreakup {

   private Long lastChancePoints;
   private double extendablePoints;
   private Long depositedPointsLastYear;
   private Long depositedPointsThisYear;
   private Long borrowablePoints;
   private Long expiringPoints;
   private Long totalDBLPoints;
}