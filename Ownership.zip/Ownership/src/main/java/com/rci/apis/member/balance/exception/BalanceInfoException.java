package com.rci.apis.member.balance.exception;

import org.apache.commons.lang3.StringUtils;

import com.rci.apis.member.balance.constants.ApplicationErrorConstants;
import com.rci.service.common.exception.BaseServiceException;
import com.rci.service.common.util.ErrorMessageFormatter;

public class BalanceInfoException extends BaseServiceException {

	/** Unique serial UID */
	private static final long serialVersionUID = 5016875811310982160L;
	private static final String DEFAULT_ERROR_CODE = ErrorMessageFormatter.
			formatErrorCode(ApplicationErrorConstants.SERVICE, ApplicationErrorConstants.GET_PTS_BAL, 
					ApplicationErrorConstants.GENERAL_EXCEPTION);
	
	public BalanceInfoException(String errorMessage) {
		super(errorMessage, DEFAULT_ERROR_CODE);
	}
	
	public BalanceInfoException(String errorMessage, Throwable t) {
		super(errorMessage, t, DEFAULT_ERROR_CODE);
	}
	
	public BalanceInfoException(String errorMessage, String errorCode) {
		super(errorMessage, StringUtils.isNotBlank(errorCode)? ErrorMessageFormatter.
				formatErrorCode(ApplicationErrorConstants.SERVICE,	ApplicationErrorConstants.GET_PTS_BAL, errorCode) : 
					DEFAULT_ERROR_CODE);
	}
	
	public BalanceInfoException(String errorMessage, String errorCode, Throwable t) {
		super(errorMessage, t, StringUtils.isNotBlank(errorCode)? ErrorMessageFormatter.
				formatErrorCode(ApplicationErrorConstants.SERVICE,	ApplicationErrorConstants.GET_PTS_BAL, errorCode) : 
					DEFAULT_ERROR_CODE);
	}
}
