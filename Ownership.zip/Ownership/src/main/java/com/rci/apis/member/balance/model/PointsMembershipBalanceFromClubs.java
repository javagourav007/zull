package com.rci.apis.member.balance.model;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModel;
import lombok.Data;

/**
 * Points Balance Information from Clubs.
 */

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@ApiModel("Points Balance Information from Clubs")
public class PointsMembershipBalanceFromClubs {
	
	private String memberID;
	
	private long currentYearBalance;
	private long nextYearBalance;
	private long thirdYearBalance;

	private LocalDate currentYearStartDate;
	private LocalDate nextYearStartDate;
	private LocalDate thirdYearStartDate;

	private LocalDate currentYearEndDate;
	private LocalDate nextYearEndDate;
	private LocalDate thirdYearEndDate;

}
