package com.rci.apis.member.balance.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDate;

@Data
@ApiModel("Customer Owenership Details")
public class MemberInventoryEntity {
    @ApiModelProperty("Ownership Contact Number")
    private Integer contractNumber;

    @ApiModelProperty("Ownership Property Code")
    private String propertyCode;

    @ApiModelProperty("Inventory Usage Code")
    private String inventoryUsageCode;

    @ApiModelProperty("Contract Points")
    private Long contractPoints;

    @ApiModelProperty("Weeks Interval")
    private Integer weekInterval;

    @ApiModelProperty("Unit Number of a Property")
    private String unitNo;

    @ApiModelProperty("Unit Type of a Property")
    private String unitType;

    @ApiModelProperty("Unit Type Description of a Property")
    private String unitTypeDescription;

    @ApiModelProperty("Season")
    private String season;

    @ApiModelProperty("Home Week Indicator")
    private String homeWeekIndicator;

    @ApiModelProperty("Home Group Indicator")
    private String homeGroupIndicator;

    @ApiModelProperty("Home Resort Indicator")
    private String homeResortIndicator;

    @ApiModelProperty("Pure Points Indicator")
    private String purePointIndicator;

    @ApiModelProperty("Contract Expiration Date")
    private LocalDate contractExpirationDate;

    @ApiModelProperty("Affiliate Code")
    private String affiliateCode;

}
