package com.rci.apis.member.balance.exception;

import org.apache.commons.lang3.StringUtils;

import com.rci.apis.member.balance.constants.ApplicationErrorConstants;
import com.rci.service.common.exception.BaseServiceException;
import com.rci.service.common.util.ErrorMessageFormatter;
public class PointsMemberInventoryExcecption extends BaseServiceException {

	/** Unique serial UID */
	private static final long serialVersionUID = 5016875811310982160L;
	private static final String DEFAULT_ERROR_CODE = ErrorMessageFormatter.
			formatErrorCode(ApplicationErrorConstants.SERVICE, ApplicationErrorConstants.GET_PTS_OWN, 
					ApplicationErrorConstants.GENERAL_EXCEPTION);
	
	public PointsMemberInventoryExcecption(String errorMessage) {
		super(errorMessage, DEFAULT_ERROR_CODE);
	}
	
	public PointsMemberInventoryExcecption(String errorMessage, Throwable t) {
		super(errorMessage, t, DEFAULT_ERROR_CODE);
	}
	
	public PointsMemberInventoryExcecption(String errorMessage, String errorCode) {
		super(errorMessage, StringUtils.isNotBlank(errorCode)? ErrorMessageFormatter.
				formatErrorCode(ApplicationErrorConstants.SERVICE,	ApplicationErrorConstants.GET_PTS_OWN, errorCode) : 
					DEFAULT_ERROR_CODE);
	}
	
	public PointsMemberInventoryExcecption(String errorMessage, String errorCode, Throwable t) {
		super(errorMessage, t, StringUtils.isNotBlank(errorCode)? ErrorMessageFormatter.
				formatErrorCode(ApplicationErrorConstants.SERVICE,	ApplicationErrorConstants.GET_PTS_OWN, errorCode) : 
					DEFAULT_ERROR_CODE);
	}
}
