package com.rci.apis.member.balance.constants;

public enum PointsOrigin {
	CLUB_ORIGIN, DBL_ORIGIN
}
