package com.rci.apis.member.balance.entity;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@ApiModel("Points Membership Summary")
public class PointsMembershipSummary implements Serializable {
	
	@ApiModelProperty(value = "The Constant serialVersionUID")
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "Club Points")
	private long clubPoints;
	
	@ApiModelProperty(value = "Club Points Deposited")
	private long clubPointsDeposited;
	
	@ApiModelProperty(value = "Points Membership Balance from Clubs")
	private PointsBalanceFromClubs pointsMembershipBalanceFromClubs;
	
	@ApiModelProperty(value = "Points Membership Balance from RCI")
	private PointsMembershipBalance pointsMembershipBalanceFromRCI;
	
	@ApiModelProperty(value = "The Points Summary balances")
    private List<PointsMembershipBalance> pointsBalanceDetails;
	
	@ApiModelProperty(value = "Maximum Extendable points")
    private long maxExtendPoints;

}
