package com.rci.apis.member.balance.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;

@Data
@ApiModel("SynergexMemberProfile")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SynergexMemberProfile {

	@ApiModelProperty("Currency Code")
	private String currencyCode;
	
	@ApiModelProperty("Sub Type")
	private String subType;
	
	@ApiModelProperty("Membership Type Description")
	private String membershipTypeDescription;
	
	@ApiModelProperty("Service Code")
	private String serviceCode;
	
	@ApiModelProperty("Service Code Description")
	private String serviceCodeDescription;
	
	@ApiModelProperty("Expiration Date")
	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate expirationDate;
	
	@ApiModelProperty("Paid Through Date")
	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate paidThroughDate;	
	
	@ApiModelProperty("weeks Currency Code")
	private String weeksCurrencyCode;	
	
	@ApiModelProperty("Is Member Auto Renewable")
	private boolean isMembersAutoRenewable;
	
	@ApiModelProperty("Possible Paid Through Date")
	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate possiblePaidThruDate;
	
	@ApiModelProperty("Member tier")
	private MemberTier memberTier;
		
	@ApiModelProperty("Is Unit Upgrade Allowed")
	private boolean isUnitUpgradeAllowed;
	
	@ApiModelProperty("Is Developer Paid Platinum Fee")
	private boolean isDeveloperPaidPlatinumFee;
	
	@ApiModelProperty("Is Developer Paid Membership Fee")
	private boolean isDeveloperPaidStandardMembershipFee;
	
	@ApiModelProperty("Member Reward Dollar")
	private BigDecimal memberRewardDollar;
	
	@ApiModelProperty("Is Member Eligible To Upgrade Tier")
	private boolean isMemberEligibleToUpgradeTier;
	
	@ApiModelProperty("Extend Points Function Present")
	private boolean extendPointsFunctionPresent;
	
	@ApiModelProperty("Direct Debit User")
	private boolean directDebitUser;
	
	@ApiModelProperty("Standard Renew Function Present")
	private boolean standardRenewFunctionPresent;
	
	@ApiModelProperty("Is Eligible For Standard Renew")
	private boolean isEligibleForStandardRenew;
	
	/**
	 * This value will be part of Points Balance
	 * */
	@ApiModelProperty("Points Membership Balance")
	private PointsMembershipBalance pointsMembershipBalance;
	
	@ApiModelProperty("Current Points Balance")
	private long currentPointsBalance;
	
	@ApiModelProperty("Current Use end Date")
	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate currentUseEndDate;
	
	@ApiModelProperty("Current Restricted Points")
	private long currentRestrictedPoints;
	
	@ApiModelProperty("Next Year Points")
	private long nextYearPoints;
	
	@ApiModelProperty("Next Year end Date")
	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate nextYearEndDate;
	
	@ApiModelProperty("Next Year Restricted Points")
	private long nextYearRestrictedPoints;
	
	@ApiModelProperty("Third Year Points")
	private long thirdYearPoints;
	
	@ApiModelProperty("Third Year end Date")
	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate thirdYearEndDate;
	
	@ApiModelProperty("Third Year Restricted Points")
	private long thirdYearRestrictedPoints ;
	
	@ApiModelProperty("Dues Balance")
	private double duesBalance ;
	
	@ApiModelProperty("Block Indicator")
	private String blockIndicator;
	
	@ApiModelProperty("Block Points Year Indicator")
	private String blockPointsYearIndicator;
	
	@ApiModelProperty("Maximum Extendable Points")
	private long maxExtendablePoints;

}
