package com.rci.apis.member.balance.entity;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MemberTier {
	
	/** The member tier type. */
	private String memberTierType;

	/** The start date. */
	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate startDate;

	/** The end date. */
	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate endDate;
	
	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate pltAutoRenewEnrollDate;
	
	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate pltAutoRenewCancelDate;

}
