package com.rci.apis.member.balance.entity;

import lombok.Data;

/**
 * Membership model which has all the properties about membership information.
 *
 */
@Data
public class MembershipInfo {

	private String pointsServiceOfficeCode;

	private String clubId;	
	
	private String membershipSubType;
	
}
