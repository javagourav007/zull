package com.rci.apis.member.balance.exception;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.rci.service.common.exception.BaseServiceException;
import com.rci.service.common.model.ErrorMessage;

import brave.Span;
import brave.Tracer;
import feign.FeignException;
import lombok.extern.slf4j.Slf4j;

@RestControllerAdvice
@Slf4j
public class PointsOwnershipExceptionAdvice extends ResponseEntityExceptionHandler {
	
	private final Tracer tracer;

	private HttpHeaders responseHeaders;

	public PointsOwnershipExceptionAdvice(Tracer tracer) {
		this.tracer = tracer;
		this.responseHeaders = new HttpHeaders();
	}

	private String getTraceId() {
		Span currentSpan = this.tracer.currentSpan();
		return currentSpan.context().traceIdString();
	}
	
	@ExceptionHandler(BalanceInfoException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<ErrorMessage> handleBalanceInfoException(BalanceInfoException e) {
		ErrorMessage errorMessage = buildErrorMessage(e);
		log.error("Error Occurred : {}", errorMessage);
		responseHeaders.set("TraceId", getTraceId());
        return new ResponseEntity<>(errorMessage, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(FeignException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<ErrorMessage> handleDBLException(FeignException e) {
		ErrorMessage errorMessage = buildErrorMessage(e);
		log.error("Error Occurred : {}", errorMessage);
		responseHeaders.set("TraceId", getTraceId());
        return new ResponseEntity<>(errorMessage, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(PointsMemberInventoryExcecption.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<ErrorMessage> handlePointsMemberInventoryExcecption(PointsMemberInventoryExcecption e) {
		ErrorMessage errorMessage = buildErrorMessage(e);
		log.error("Error Occurred : {}", errorMessage);
		responseHeaders.set("TraceId", getTraceId());
        return new ResponseEntity<>(errorMessage, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<ErrorMessage> handleOwnershipException(Exception e) {
		ErrorMessage errorMessage = buildErrorMessage(e);
		log.error("Error Occurred : {}", errorMessage);
		responseHeaders.set("TraceId", getTraceId());
        return new ResponseEntity<>(errorMessage, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	private ErrorMessage buildErrorMessage(Exception e) {
		ErrorMessage errorMessage = new ErrorMessage();
    	
    	if (e instanceof BaseServiceException) {
            BaseServiceException base = (BaseServiceException) e;
            errorMessage.setCode(base.getCode());
            errorMessage.setMessage(base.getMessage());
            errorMessage.setStackTrace(ExceptionUtils.getStackTrace(e));
            
        }else {
			errorMessage.setMessage(e.getMessage());
        	errorMessage.setStackTrace(ExceptionUtils.getStackTrace(e));
        }
    	return errorMessage;
    }
}
