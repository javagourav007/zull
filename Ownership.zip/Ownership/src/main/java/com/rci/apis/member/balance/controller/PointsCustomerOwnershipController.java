package com.rci.apis.member.balance.controller;

import java.util.List;

import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rci.apis.member.balance.model.Ownership;
import com.rci.apis.member.balance.service.PointsMemberInventoryService;
import com.rci.service.common.model.ConsumerChannel;
import com.rci.service.common.model.MemberType;

import brave.Span;
import brave.Tracer;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

/**
 * PointsCustomerOwnershipController class will expose the end points for
 * member's ownership related services.
 */
@Api(value = "PointsCustomerOwnershipController")
@RestController
@Validated
@Slf4j
@RequestMapping("/points")
public class PointsCustomerOwnershipController {
	@Autowired
	private PointsMemberInventoryService service;
	
	private final Tracer tracer;

	private HttpHeaders responseHeaders;

	public PointsCustomerOwnershipController(Tracer tracer) {
		this.tracer = tracer;
		this.responseHeaders = new HttpHeaders();
	}

	private String getTraceId() {
		Span currentSpan = this.tracer.currentSpan();
		return currentSpan.context().traceIdString();
	}
	/**
	 * Retrieves the member balance information depending upon the member Id.
	 * 
	 * @param customerId        The unique id for the member
	 * @param consumerChannel The ConsumerChannel.
	 * @param MemberType      Type of the member points or weeks
	 * @param OperatorId	 Unique operator id.  
	 * @return the balance information for the member.
	 */
	@ApiOperation(value = "getMemberOwnership",
				  nickname = "getMemberOwnership", 
				  notes = "Retrieves the Customer Ownership Information depending upon the LeadId (i.e Resort Details, Contract Number, Contract Expiration Date, Home Week/Group/Resort Indicator etc)", 
				  response = Ownership.class, 
				  tags = {"member-ownership" })
	
	@GetMapping("/{customerId}/ownerships/details")
	public ResponseEntity<List<Ownership>> getMemberOwnership(
			@PathVariable("customerId") @NotNull String leadId,
			@RequestHeader(value = "ConsumerChannel",required = true) ConsumerChannel consumerChannel,
			@RequestHeader(value = "MemberType", required = true) @NotNull MemberType memberType,
			@RequestHeader(value = "OperatorId",required = true) String operatorId) {

		log.info("Entering getMemberOwnership for customerId: {}, memberType : {}, consumerChannel : {}, operatorId : {}",
				leadId, memberType, consumerChannel, operatorId);
		List<Ownership> transactions = service.getMemberInventory(leadId, operatorId, consumerChannel);
		responseHeaders.set("TraceId", getTraceId()); 

		log.info("Exit getMemberOwnership for customerId: {}, memberType : {}, consumerChannel : {}, operatorId : {}",
				leadId, memberType, consumerChannel, operatorId);
		return new ResponseEntity<>(transactions, responseHeaders, HttpStatus.OK);
	}

}
