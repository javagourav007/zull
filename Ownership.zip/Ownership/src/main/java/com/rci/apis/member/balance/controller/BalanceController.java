package com.rci.apis.member.balance.controller;

import java.time.LocalDate;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.rci.apis.member.balance.cache.PointsBalanceCacheManager;
import com.rci.apis.member.balance.entity.PointsBalanceFromClubs;
import com.rci.apis.member.balance.model.PointsBalance;
import com.rci.apis.member.balance.model.PointsMembershipBalanceFromClubs;
import com.rci.apis.member.balance.service.BalanceService;
import com.rci.service.common.model.ConsumerChannel;
import com.rci.service.common.model.MemberType;
import com.rci.service.common.model.Status;

import brave.Span;
import brave.Tracer;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

/**
 * BalanceController class will expose the end points for member's balance
 * related services.
 */
@Api(value = "BalanceController")
@RestController
@Validated
@Slf4j
@RequestMapping("/points")
public class BalanceController {

	/**
	 * The Balance service is used to Retrieve the balance information depending
	 * upon the member Id.
	 * 
	 */
	@Autowired
	private BalanceService balanceService;

	@Autowired
	private PointsBalanceCacheManager pointsBalanceCacheManager;

	private final Tracer tracer;

	private HttpHeaders responseHeaders;

	public BalanceController(Tracer tracer) {
		this.tracer = tracer;
		this.responseHeaders = new HttpHeaders();
	}

	private String getTraceId() {
		Span currentSpan = this.tracer.currentSpan();
		return currentSpan.context().traceIdString();
	}

	/**
	 * Retrieves the member balance information depending upon the member Id.
	 * 
	 * @param memberId        The unique id for the member
	 * @param consumerChannel The ConsumerChannel.
	 * @param operatorId      Unique identifier for the Operator.
	 * @param memberType  Type of the member points or weeks
	 * @return the balance information for the member.
	 */
	@ApiOperation(value = "getPointsBalance",
				  nickname = "getPointsBalance", 
				  notes = "Retrieves the Points Balance information depending upon the Member ID", 
				  response = PointsBalance.class, 
				  tags = {"member-balance" })
	@GetMapping(value = { "/{customer-id}/ownerships/balance" }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<PointsBalance> getPointsBalance(
			@PathVariable("customer-id") @NotBlank String memberId, 
			@RequestHeader(value = "ConsumerChannel", required = true) @NotNull ConsumerChannel consumerChannel,
			@RequestHeader(value = "MemberType", required = true) @NotNull MemberType memberType,
			@RequestHeader(value = "OperatorId", required = true) @NotBlank String operatorId,
            @RequestParam(value = "startDate", required = false) @DateTimeFormat(iso = ISO.DATE) LocalDate startDate) {
					
		log.info("Entering getBalanceInfo for memberId: {}, memberType : {}, consumerChannel : {}, operatorId : {}",
				memberId, memberType, consumerChannel, operatorId);

		PointsBalance pointsBalance = balanceService.
				getBalanceInfo(memberId, consumerChannel, operatorId, startDate, memberType);
			
		responseHeaders.set("TraceId", getTraceId()); 

		log.info("Exit getBalanceInfo for memberId: {}, memberType : {}, consumerChannel : {}, operatorId : {}",
					memberId, memberType, consumerChannel, operatorId);
             
		return new ResponseEntity<>(pointsBalance, responseHeaders, HttpStatus.OK);
       }

	@ApiOperation(value = "populatePtsMembershipDetailsClubs", 
				  nickname = "populatePtsMembershipDetailsClubs", 
				  notes = "Service to load the Points membership details into cache", 
				  response = Status.class, 
				  tags = {"member-balance" })
	@PostMapping(path = "/{customer-id}/ownerships/balance", consumes = "application/json", produces = "application/json")
	public ResponseEntity<Status> populatePtsMembershipDetailsClubs(
			@RequestBody PointsMembershipBalanceFromClubs ptsMembershipBalanceFromClubs,
			@RequestHeader(value = "ConsumerChannel", required = true) @NotNull ConsumerChannel consumerChannel,
			@RequestHeader(value = "MemberType", required = true) @NotNull MemberType memberType,
			@RequestHeader(value = "OperatorId", required = true) @NotBlank String operatorId,
			@PathVariable("customer-id") @NotBlank String customerId) {

		log.info("Entering populatePtsMembershipDetailsClubs for consumerChannel : {}, memberType : {}, operatorId : {}",
				consumerChannel, memberType, operatorId);

		String cacheKey = ptsMembershipBalanceFromClubs.getMemberID();
		PointsBalanceFromClubs pointsMembershipBalanceFromClubs = new PointsBalanceFromClubs();
		Status status = new Status();

		/* Clear the cache for PtsMemberBalanceClubsCache */
		status = pointsBalanceCacheManager.clearPtsMemberBalanceClubsCache(cacheKey);

		/* Load the details to cache */
		pointsMembershipBalanceFromClubs = pointsBalanceCacheManager.
				populatePtsMembershipDetailsClubs(ptsMembershipBalanceFromClubs);
		
		if(null != pointsMembershipBalanceFromClubs){
			status.setStatus(true);
		}
			
		responseHeaders.set("TraceId", getTraceId());
		
		log.info("Exiting from populatePtsMembershipDetailsClubs() method "
				+ "for consumerChannel : {}, memberType : {},  operatorId : {}",
				consumerChannel, memberType, operatorId);

		return new ResponseEntity<>(status, responseHeaders, HttpStatus.OK);
	}
}
