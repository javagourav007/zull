package com.rci.apis.member.balance.mapper;

import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.rci.apis.member.balance.cache.PointsBalanceCacheManager;
import com.rci.apis.member.balance.entity.PointsMembershipBalance;
import com.rci.apis.member.balance.entity.PointsBalanceFromClubs;
import com.rci.apis.member.balance.entity.PointsMembershipSummary;
import com.rci.apis.member.balance.entity.SynergexMemberInfoSummary;
import com.rci.apis.member.balance.entity.SynergexMemberProfile;
import com.rci.apis.member.balance.entity.SynergexPointsInquiry;

import lombok.extern.slf4j.Slf4j;

/**
 * Mapper to populate PointsMembershipSummary model from SynergexPointsMembership, SynergexMemberInfoSummary, SynergexMemberProfile.
 *
 */
@Component
@Slf4j
@Mapper(componentModel = "spring")
public abstract class PointsMembershipSummaryMapper {
	
	@Autowired
	PointsBalanceCacheManager pointsBalanceCacheManager;
	
	/**
	 * Mapper to populate PointsMembershipSummary model from SynergexPointsMembership, SynergexMemberInfoSummary, SynergexMemberProfile entities.
	 * @param synergexPointsMembershipDetails SynergexPointsMembership entity
	 * @param synergexMemberInfoSummary SynergexMemberInfoSummary entity
	 * @param synergexMemberProfile SynergexMemberProfile entity
	 * @return PointsMembershipSummary model.
	 */
	public abstract PointsMembershipSummary map(String memberId,SynergexPointsInquiry synergexPointsInquiryDetails,SynergexMemberInfoSummary synergexMemberInfoSummary,
			SynergexMemberProfile synergexMemberProfile);
	
	/**
	 * Additional mapping for the properties in SynergexPointsMembership, SynergexMemberInfoSummary, SynergexMemberProfile entities to the PointsMembershipSummary model.
	 * @param synergexPointsMembershipDetails SynergexPointsMembership entity
	 * @param synergexMemberInfoSummary SynergexMemberInfoSummary entity
	 * @param synergexMemberProfile SynergexMemberProfile entity
	 * @param ptsMembershipDetails PointsMembershipSummary model.
	 */
	@AfterMapping
	protected void afterMapping(String memberId,SynergexPointsInquiry synergexPointsInquiryDetails,SynergexMemberInfoSummary synergexMemberInfoSummary,SynergexMemberProfile synergexMemberProfile,
			@MappingTarget PointsMembershipSummary ptsMembershipDetails) {
		
		log.debug("Enter afterMapping");
		
		PointsBalanceFromClubs pointsMembershipBalanceFromClubs = new PointsBalanceFromClubs();
		pointsMembershipBalanceFromClubs.setMemberID(memberId);
		
		PointsMembershipBalance pointsMembershipBalanceFromRCI = new PointsMembershipBalance();
		long clubPoints = 0;
		long clubPointsDeposited = 0;
		
		
		if(null != synergexMemberProfile){
			pointsMembershipBalanceFromRCI.setCurrentYearBalance(synergexMemberProfile.getPointsMembershipBalance().getCurrentYearBalance());
			pointsMembershipBalanceFromRCI.setCurrentYearStartDate(synergexMemberProfile.getPointsMembershipBalance().getCurrentYearStartDate());
			pointsMembershipBalanceFromRCI.setNextYearBalance(synergexMemberProfile.getPointsMembershipBalance().getNextYearBalance());
			pointsMembershipBalanceFromRCI.setNextYearEndDate(synergexMemberProfile.getPointsMembershipBalance().getNextYearEndDate());
			pointsMembershipBalanceFromRCI.setNextYearStartDate(synergexMemberProfile.getPointsMembershipBalance().getNextYearStartDate());
			pointsMembershipBalanceFromRCI.setThirdYearBalance(synergexMemberProfile.getPointsMembershipBalance().getThirdYearBalance());
			pointsMembershipBalanceFromRCI.setThirdYearEndDate(synergexMemberProfile.getPointsMembershipBalance().getThirdYearEndDate());
			pointsMembershipBalanceFromRCI.setThirdYearStartDate(synergexMemberProfile.getPointsMembershipBalance().getThirdYearStartDate());
			pointsMembershipBalanceFromRCI.setCurrentRestrictedPoints(synergexMemberProfile.getPointsMembershipBalance().getCurrentRestrictedPoints());
			pointsMembershipBalanceFromRCI.setNextYearRestrictedPoints(synergexMemberProfile.getPointsMembershipBalance().getNextYearRestrictedPoints());
			pointsMembershipBalanceFromRCI.setThirdYearRestrictedPoints(synergexMemberProfile.getPointsMembershipBalance().getThirdYearRestrictedPoints());
			
			clubPointsDeposited = synergexMemberProfile.getPointsMembershipBalance().getCurrentYearBalance() + 
									synergexMemberProfile.getPointsMembershipBalance().getNextYearBalance() + 
									synergexMemberProfile.getPointsMembershipBalance().getThirdYearBalance();
		}
		
		if(null != synergexMemberInfoSummary.getCurrentUseYearEndDate()){
			pointsMembershipBalanceFromRCI.setCurrentYearEndDate(synergexMemberInfoSummary.getCurrentUseYearEndDate());
		}
		
		ptsMembershipDetails.setClubPointsDeposited(clubPointsDeposited);
		ptsMembershipDetails.setPointsMembershipBalanceFromClubs(pointsBalanceCacheManager.getPtsMembershipDetailsClubs(pointsMembershipBalanceFromClubs));
		ptsMembershipDetails.setPointsMembershipBalanceFromRCI(pointsMembershipBalanceFromRCI);
		
		if(null != ptsMembershipDetails.getPointsMembershipBalanceFromClubs()){
			
			clubPoints = ptsMembershipDetails.getPointsMembershipBalanceFromClubs().getCurrentYearBalance() + 
						 ptsMembershipDetails.getPointsMembershipBalanceFromClubs().getNextYearBalance() + 
						 ptsMembershipDetails.getPointsMembershipBalanceFromClubs().getThirdYearBalance();
		}
		
		ptsMembershipDetails.setClubPoints(clubPoints);
		
		if(null != synergexPointsInquiryDetails.getPointsMembershipBalances()){
			ptsMembershipDetails.setPointsBalanceDetails(synergexPointsInquiryDetails.getPointsMembershipBalances());
		}
		if(null != synergexMemberProfile){
			ptsMembershipDetails.setMaxExtendPoints(synergexMemberProfile.getMaxExtendablePoints());
		}
		
		log.debug("Exit afterMapping");
	}
}
