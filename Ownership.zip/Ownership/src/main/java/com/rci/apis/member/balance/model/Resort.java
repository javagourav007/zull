package com.rci.apis.member.balance.model;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@ApiModel("Member Home Group Resort")
public class Resort {
	@ApiModelProperty("Resort Id")
	private String resortId;
	
	@ApiModelProperty("Resort Name")
	private String resortName;
	
	@ApiModelProperty("Affiliated Code")
	private String affiliatedCode;
	
	
}
