package com.rci.apis.member.balance.mapper;


import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.rci.apis.member.balance.entity.MemberInventoryEntity;
import com.rci.apis.member.balance.entity.ResortEntity;
import com.rci.apis.member.balance.model.Ownership;
import com.rci.apis.member.balance.model.Resort;
import com.rci.apis.member.balance.repository.OwnershipRepository;

@Component
@Mapper(componentModel = "spring")
public abstract class SynMemberInventoryEntityMapper{
	
	@Autowired
	private OwnershipRepository repository;
	
    @Mappings({
            @Mapping(target = "affiliateCode", source = "affiliateCode"),
            @Mapping(target = "contractExpDate", source = "contractExpirationDate"),
            @Mapping(target = "contractNo", source = "contractNumber"),
            @Mapping(target = "contractPoints", source = "contractPoints"),
            @Mapping(target = "homeGroupInd", source = "homeGroupIndicator"),
            @Mapping(target = "homeResortInd", source = "homeResortIndicator"),
            @Mapping(target = "homeWeekInd", source = "homeWeekIndicator"),
            @Mapping(target = "inventoryUsageCode", source = "inventoryUsageCode"),
            @Mapping(target = "propertyCode", source = "propertyCode"),
            @Mapping(target = "purePointInd", source = "purePointIndicator"),
            @Mapping(target = "season", source = "season"),
            @Mapping(target = "unitNo", source = "unitNo"),
            @Mapping(target = "unitType", source = "unitType"),
            @Mapping(target = "unitTypeDescription", source = "unitTypeDescription"),
            @Mapping(target = "weekInterval", source = "weekInterval")
    })
    public abstract Ownership map(MemberInventoryEntity from);
    
    /**
	 * Additional mapping for the properties in MemberInventoryEntity entity to the Ownership model.
	 * @param accountDetailsForCWP from - Entity for fetching the inventory details from synergex InventoryGateway.
	 * @param ownership Ownership model.
	 */
	@AfterMapping
	protected void afterMapping(MemberInventoryEntity from, @MappingTarget Ownership ownership) {
		List<Resort> resorts=new ArrayList<>();
		if(StringUtils.isNotBlank(from.getAffiliateCode())){
			List<ResortEntity> resortEntities=repository.findAffiliatedHGByAffCode(from.getAffiliateCode()).orElse(null);
			if (CollectionUtils.isNotEmpty(resortEntities)) {
				resortEntities.forEach(resortEntity -> {
					Resort resort = new Resort();
					resort.setResortId(resortEntity.getResortId());
					resort.setResortName(resortEntity.getResortName());
					resort.setAffiliatedCode(resortEntity.getAffiliatedCode());
					resorts.add(resort);
				});
			} 
			ownership.setAffiliatedHomeGroups(resorts);
		}
		
	}
	
	 @Mappings({
         @Mapping(target = "resortId", source = "resortId"),
         @Mapping(target = "resortName", source = "resortName"),
         @Mapping(target = "affiliatedCode", source = "affiliatedCode"),
        
 })
 public abstract Resort mapResort(ResortEntity from);
 public abstract List<Resort> mapResort(List<ResortEntity> from);
}
