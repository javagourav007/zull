package com.rci.apis.member.balance.service;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rci.apis.member.balance.constants.ApplicationErrorConstants;
import com.rci.apis.member.balance.entity.AccountDetailsForClub;
import com.rci.apis.member.balance.exception.BalanceInfoException;
import com.rci.apis.member.balance.mapper.PointsBalanceEntityMapper;
import com.rci.apis.member.balance.model.PointsBalance;
import com.rci.apis.member.balance.service.BalanceService;
import com.rci.service.common.exception.BaseServiceException;
import com.rci.service.common.model.ConsumerChannel;
import com.rci.service.common.model.MemberType;

import feign.FeignException;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 *  BalanceServiceImpl class provides the service methods for Member balance.
 * 
 */
@Getter
@Setter
@Slf4j
@Service
public class BalanceService {
	
	/** ClubAccountDetailsService service */
	@Autowired
	protected ClubAccountDetailsService accountDetailsService;
	
	/** PointsBalanceEntityMapper balanceMapper */
	@Autowired
	protected PointsBalanceEntityMapper pointsBalanceMapper;
	
	private static final String FEIGN_EXCEPTION ="Feign Exception";
	private static final String GENERAL_EXCEPTION ="General Exception";
	
	/**
	 * Gets balance Info for a Member.
	 * @param memberId  The unique identifier for the member
	 * @param consumerChannel  The ConsumerChannel
	 * @param operatorId Unique identifier for the Operator.
	 * @param startDate The start date
	 * @param membershipType Type of the member points or weeks
	 * @param membershipSubType Membership Sub Type for the member
	 * @return PointsBalance - Points Balance information for the CWP Member
	 */
	public PointsBalance getBalanceInfo(String memberId, ConsumerChannel consumerChannel, String operatorId, LocalDate startDate,
			MemberType membershipType) {

		log.debug("Entering into the getBalanceInfo for memberId: {}, membershipType: {}", memberId, membershipType);
		
		try {
				if (MemberType.POINTS.equals(membershipType)) {
					return getPointsBalance(memberId, consumerChannel, operatorId, startDate, membershipType);
				}else {
						/* TO DO */
						return null;
				}
		}catch (BaseServiceException e) {
			throw e;
		}catch (FeignException e) {
			throw new BalanceInfoException(FEIGN_EXCEPTION, ApplicationErrorConstants.SERVICE_LOCATOR_EXCEPTION, e);
		}catch (Exception e) {
			throw new BalanceInfoException(GENERAL_EXCEPTION, e);
		}
			
	}
	
	/**
	 * Gets balance Info for Points Member
	 * @param memberId The unique identifier for the member
	 * @param consumerChannel The ConsumerChannel
	 * @param operatorId Unique identifier for the Operator
	 * @param startDate The start date
	 * @param membershipSubType Membership Sub Type for the member
	 * @return PointsBalance model
	 */
	private PointsBalance getPointsBalance(String memberId, ConsumerChannel consumerChannel, String operatorId, LocalDate startDate, MemberType memberType) {
		
		log.debug("Entering into getPointsBalance method");
		AccountDetailsForClub accountDetailsForCWP = null;

		log.debug("Invoking calculateCWPBalance method");
		accountDetailsForCWP = accountDetailsService.calculateCWPBalance(memberId, consumerChannel, operatorId, startDate, memberType);
				
		log.debug("Received response from calculateCWPBalance:{}", accountDetailsForCWP);

		log.debug("Exiting from getPointsBalance method");
		return pointsBalanceMapper.map(accountDetailsForCWP);

	}
}
