package com.rci.apis.member.balance.service;

import java.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rci.apis.member.balance.constants.PointsMembershipBalanceType;
import com.rci.apis.member.balance.constants.PointsNature;
import com.rci.apis.member.balance.constants.PointsOrigin;
import com.rci.apis.member.balance.entity.AccountDetailsForClub;
import com.rci.apis.member.balance.entity.PointsMembershipBalance;
import com.rci.apis.member.balance.entity.PointsBalanceFromClubs;
import com.rci.apis.member.balance.entity.PointsMembershipSummary;
import com.rci.service.common.model.ConsumerChannel;
import com.rci.service.common.model.MemberType;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 *  CWPAccountDetailsServiceImpl class provides the service methods for calculating Member balance.
 * 
 */
@Getter
@Setter
@Slf4j
@Service
public class CWPAccountDetailsServiceImpl implements ClubAccountDetailsService {

	/** ClubCustomerAccountSummaryServiceImpl service */
	@Autowired
	protected ClubCustomerAccountSummaryService clubCustomerAccountSummary;
	
	/**
	 * Calculate balance Info for a CWP Member.
	 * @param memberId  The unique identifier for the member
	 * @param consumerChannel  The ConsumerChannel
	 * @param operatorId Unique identifier for the Operator
	 * @param startDate The start date
	 * @param membershipSubType Membership Sub Type for the member
	 * @return AccountDetailsForClub - Account Details information for the CWP Member
	 */
	@Override
	public AccountDetailsForClub calculateCWPBalance(String memberId, ConsumerChannel consumerChannel,
			String operatorId, LocalDate startDate, MemberType memberType) {
		
		log.debug("Entering into calculateCWPBalance method for memberId: {}", memberId);
		
		LocalDate currentYearEndDate;
		LocalDate nextYearEndDate;
		LocalDate thirdYearEndDate;
		LocalDate nextYearStartDate;
		LocalDate thirdYearStartDate;

		long currentYearBalance=0;
		long nextYearBalance=0;
		long thirdYearBalance=0;
		
		long savedCurrentYearBalance=0;
		long savedNextYearBalance=0;
		long savedThirdYearBalance=0;
		
		long standardCurrentYearBalance=0;
		long standardNextYearBalance=0;
		long standardThirdYearBalance=0;
		
		long extendedCurrentYearBalance=0;
		long extendedNextYearBalance=0;
		long extendedThirdYearBalance=0;
		
		long usageCurrentYearBalance=0;
		long usageNextYearBalance=0;
		long usageThirdYearBalance=0;
		
		long borrowCurrentYearBalance=0;
		long borrowNextYearBalance=0;
		long borrowThirdYearBalance=0;
		
		long forfeitedCurrentYearBalance=0;
		long forfeitedNextYearBalance=0;
		long forfeitedThirdYearBalance=0;
		
		long transferCurrentYearBalance=0;
		long transferNextYearBalance=0;
		long transferThirdYearBalance=0;
		
		long thirdYearSavePointsIn=0;
		long nextYearSavePointsOut=0;
		long nextYearSavePointsIn=0;
		long currentYearSavePointsOut=0;
		long currentYearAutoSavePoints=0;
		long currentYearAvailableStandardPoints=0;
		long nextYearAvailableStandardPoints=0;
		long thirdYearAvailableStandardPoints=0;
		long thirdYearSavePointsOut=0;
		long otherPointInCurrentYear=0;
		long otherPointInNextYear=0;
		long otherPointInThirdYear=0;
		
		long currentYearExpiryPoints=0;
		long nextYearExpiryPoints=0;
		long thirdYearExpiryPoints=0;
		
		long currentYearClubPoint = 0;
		long nextYearClubPoint = 0;
		long thirdYearClubPoint = 0;
		long currentYearTotalPoint = 0;
		long nextYearTotalPoint = 0;
		long thirdYearTotalPoint = 0;
		
		long totalDBLClubPoints = 0;
		long totalClubPoints = 0;
		
		long totalDBLPointsCurrentYear = 0;
		long totalPointsCurrentYear = 0;
		long totalDBLPointsNextYear = 0;
		long totalPointsNextYear = 0;
		long totalDBLPointsThirdYear = 0;
		long totalPointsThirdYear = 0;
		
		int currentYear = 0;
		int nextYear = 0;
		int thirdYear = 0;
		
		PointsMembershipSummary ptsMembershipDetails = clubCustomerAccountSummary.
				getMbrPtsMembershipDetails(memberId, consumerChannel, operatorId, startDate, memberType);
		
		AccountDetailsForClub accountDetailsForCWP = new AccountDetailsForClub();
		
		PointsMembershipBalance ptsMembershipBalanceFromRCI = ptsMembershipDetails.getPointsMembershipBalanceFromRCI();
			
		if(ptsMembershipBalanceFromRCI!=null) {
				
			if(ptsMembershipBalanceFromRCI.getCurrentYearStartDate() != null){
				currentYearEndDate = ptsMembershipBalanceFromRCI.getCurrentYearStartDate();
				currentYearEndDate = currentYearEndDate.plusYears(1);
				currentYearEndDate = currentYearEndDate.minusDays(1);
				accountDetailsForCWP.setCurrentRCIYearEndDate(currentYearEndDate);
				currentYearBalance= ptsMembershipBalanceFromRCI.getCurrentYearBalance();
				
			}
			if(ptsMembershipBalanceFromRCI.getNextYearEndDate() != null){
				nextYearEndDate = ptsMembershipBalanceFromRCI.getNextYearEndDate();
				nextYearEndDate = nextYearEndDate.plusYears(1);
				nextYearEndDate = nextYearEndDate.minusDays(1);
				accountDetailsForCWP.setNextYearEndDate(nextYearEndDate);
				nextYearBalance= ptsMembershipBalanceFromRCI.getNextYearBalance();
			}
			if(ptsMembershipBalanceFromRCI.getThirdYearEndDate() != null){
				thirdYearEndDate = ptsMembershipBalanceFromRCI.getThirdYearEndDate();
				thirdYearEndDate = thirdYearEndDate.plusYears(1);
				thirdYearEndDate = thirdYearEndDate.minusDays(1);
				accountDetailsForCWP.setThirdYearEndDate(thirdYearEndDate);
				thirdYearBalance= ptsMembershipBalanceFromRCI.getThirdYearBalance();
			}
			
			if(accountDetailsForCWP.getCurrentRCIYearEndDate() != null){
				nextYearStartDate = accountDetailsForCWP.getCurrentRCIYearEndDate();
				nextYearStartDate = nextYearStartDate.plusDays(1);
				accountDetailsForCWP.setNextYearStartDate(nextYearStartDate);
			}
			
			if(accountDetailsForCWP.getNextYearEndDate() != null){
				thirdYearStartDate = accountDetailsForCWP.getNextYearEndDate();
				thirdYearStartDate = thirdYearStartDate.plusDays(1);
				accountDetailsForCWP.setThirdYearStartDate(thirdYearStartDate);
			}
		}
		
		if(ptsMembershipDetails!=null && ptsMembershipDetails.getPointsBalanceDetails()!=null) {
			
			for (PointsMembershipBalance pointsBalance : ptsMembershipDetails.getPointsBalanceDetails()) {
				if(pointsBalance!=null && pointsBalance.getPointsNature()!=null && pointsBalance.getPointsOrigin()!=null 
						&& pointsBalance.getPointsMembershipBalanceType()!=null) {
					
					if(pointsBalance.getPointsNature().toString().equals(PointsNature.SAVED_POINTS.toString()) &&
							pointsBalance.getPointsOrigin().toString().equals(PointsOrigin.DBL_ORIGIN.toString()) &&
							pointsBalance.getPointsMembershipBalanceType().toString().equals(PointsMembershipBalanceType.CLUB_POINTS_TYPE.toString()))	
					{
						
						savedCurrentYearBalance = pointsBalance.getCurrentYearBalance();
						savedNextYearBalance = pointsBalance.getNextYearBalance();
						savedThirdYearBalance = pointsBalance.getThirdYearBalance();
					}
		
					if(pointsBalance.getPointsNature().toString().equals(PointsNature.STANDARD_POINTS.toString()) &&
							pointsBalance.getPointsOrigin().toString().equals(PointsOrigin.DBL_ORIGIN.toString()) && 
							pointsBalance.getPointsMembershipBalanceType().toString().equals(PointsMembershipBalanceType.CLUB_POINTS_TYPE.toString())) {
						
						standardCurrentYearBalance = pointsBalance.getCurrentYearBalance();
						standardNextYearBalance = pointsBalance.getNextYearBalance();
						standardThirdYearBalance = pointsBalance.getThirdYearBalance();
					}
					
					
					if(pointsBalance.getPointsNature().toString().equals(PointsNature.EXTENDED_POINTS.toString()) &&
							pointsBalance.getPointsOrigin().toString().equals(PointsOrigin.DBL_ORIGIN.toString()) && 
							pointsBalance.getPointsMembershipBalanceType().toString().equals(PointsMembershipBalanceType.CLUB_POINTS_TYPE.toString())) {
								
						extendedCurrentYearBalance = pointsBalance.getCurrentYearBalance();
						extendedNextYearBalance = pointsBalance.getNextYearBalance();
						extendedThirdYearBalance = pointsBalance.getThirdYearBalance();
					}
					
					
					if(pointsBalance.getPointsNature().toString().equals(PointsNature.USAGE_POINTS.toString()) &&
							pointsBalance.getPointsOrigin().toString().equals(PointsOrigin.DBL_ORIGIN.toString()) &&
							pointsBalance.getPointsMembershipBalanceType().toString().equals(PointsMembershipBalanceType.CLUB_POINTS_TYPE.toString())) {
						
						usageCurrentYearBalance = pointsBalance.getCurrentYearBalance();
						usageNextYearBalance = pointsBalance.getNextYearBalance();
						usageThirdYearBalance = pointsBalance.getThirdYearBalance();
					}
					
					
					if(pointsBalance.getPointsNature().toString().equals(PointsNature.BORROW_POINTS.toString()) &&
							pointsBalance.getPointsOrigin().toString().equals(PointsOrigin.DBL_ORIGIN.toString()) &&
							pointsBalance.getPointsMembershipBalanceType().toString().equals(PointsMembershipBalanceType.CLUB_POINTS_TYPE.toString())) {
						
						borrowCurrentYearBalance = pointsBalance.getCurrentYearBalance();
						borrowNextYearBalance = pointsBalance.getNextYearBalance();
						borrowThirdYearBalance = pointsBalance.getThirdYearBalance();
					}	
					
					if(pointsBalance.getPointsNature().toString().equals(PointsNature.FORFEITED_POINTS.toString()) &&
							pointsBalance.getPointsOrigin().toString().equals(PointsOrigin.DBL_ORIGIN.toString()) &&
							pointsBalance.getPointsMembershipBalanceType().toString().equals(PointsMembershipBalanceType.CLUB_POINTS_TYPE.toString())) {
						
						forfeitedCurrentYearBalance = pointsBalance.getCurrentYearBalance();
						forfeitedNextYearBalance = pointsBalance.getNextYearBalance();
						forfeitedThirdYearBalance = pointsBalance.getThirdYearBalance();
					}
					
					
					if(pointsBalance.getPointsNature().toString().equals(PointsNature.TRANSFER_POINTS.toString()) &&
							pointsBalance.getPointsOrigin().toString().equals(PointsOrigin.DBL_ORIGIN.toString()) &&
							pointsBalance.getPointsMembershipBalanceType().toString().equals(PointsMembershipBalanceType.CLUB_POINTS_TYPE.toString())) {
						
						transferCurrentYearBalance = pointsBalance.getCurrentYearBalance();
						transferNextYearBalance = pointsBalance.getNextYearBalance();
						transferThirdYearBalance = pointsBalance.getThirdYearBalance();
					}	
				}
			}
		}
		
		thirdYearSavePointsIn=savedThirdYearBalance;
		
		if(thirdYearSavePointsIn>=0)
		{
			nextYearSavePointsOut=-thirdYearSavePointsIn;
		}
			
		nextYearSavePointsIn=savedNextYearBalance + thirdYearSavePointsIn;
		currentYearSavePointsOut=-nextYearSavePointsIn;
		currentYearAutoSavePoints=savedCurrentYearBalance + nextYearSavePointsIn;
		
		currentYearAvailableStandardPoints = currentYearSavePointsOut + standardCurrentYearBalance;
		nextYearAvailableStandardPoints = nextYearSavePointsOut + standardNextYearBalance;
		thirdYearAvailableStandardPoints = thirdYearSavePointsOut + standardThirdYearBalance;
		
		otherPointInCurrentYear = currentYearAutoSavePoints + extendedCurrentYearBalance + usageCurrentYearBalance + 
				borrowCurrentYearBalance + forfeitedCurrentYearBalance + transferCurrentYearBalance;
		otherPointInNextYear = nextYearSavePointsIn + extendedNextYearBalance + usageNextYearBalance + 
				borrowNextYearBalance + forfeitedNextYearBalance + transferNextYearBalance;
		otherPointInThirdYear = thirdYearSavePointsIn + extendedThirdYearBalance + usageThirdYearBalance + 
				borrowThirdYearBalance + forfeitedThirdYearBalance + transferThirdYearBalance;
		
		if(otherPointInCurrentYear<0)
		{
			currentYearAvailableStandardPoints=otherPointInCurrentYear+currentYearAvailableStandardPoints;
		}
		if(otherPointInNextYear<0)
		{
			nextYearAvailableStandardPoints=otherPointInNextYear+nextYearAvailableStandardPoints;
		}
		if(otherPointInThirdYear<0)
		{
			thirdYearAvailableStandardPoints=otherPointInThirdYear+thirdYearAvailableStandardPoints;
		}
		
		currentYearExpiryPoints = currentYearBalance - currentYearAvailableStandardPoints;
		nextYearExpiryPoints = nextYearBalance - nextYearAvailableStandardPoints + currentYearAvailableStandardPoints;
		thirdYearExpiryPoints = thirdYearBalance - thirdYearAvailableStandardPoints + nextYearAvailableStandardPoints;
		
		if(currentYearExpiryPoints<0)
		{
			currentYearExpiryPoints=0;
		}
		if(nextYearExpiryPoints<0)
		{
			nextYearExpiryPoints=0;
		}
		if(thirdYearExpiryPoints<0)
		{
			thirdYearExpiryPoints=0;
		}
		
		PointsBalanceFromClubs ptsMembershipBalanceFromClubs = ptsMembershipDetails.getPointsMembershipBalanceFromClubs();
		
		currentYearClubPoint = ptsMembershipBalanceFromClubs.getCurrentYearBalance();
		nextYearClubPoint = ptsMembershipBalanceFromClubs.getNextYearBalance();
		thirdYearClubPoint = ptsMembershipBalanceFromClubs.getThirdYearBalance();
		
		currentYearTotalPoint = standardCurrentYearBalance+ usageCurrentYearBalance + borrowCurrentYearBalance + 
				savedCurrentYearBalance + transferCurrentYearBalance + forfeitedCurrentYearBalance + extendedCurrentYearBalance;
		nextYearTotalPoint   = standardNextYearBalance+ savedNextYearBalance + usageNextYearBalance + 
				borrowNextYearBalance + transferNextYearBalance + forfeitedNextYearBalance + extendedNextYearBalance;
		thirdYearTotalPoint = standardThirdYearBalance+ thirdYearSavePointsIn + usageThirdYearBalance + 
				borrowThirdYearBalance + transferThirdYearBalance + forfeitedThirdYearBalance + extendedThirdYearBalance;
		
		log.debug("clubPointNextYearExpiring : " + currentYearExpiryPoints);
		accountDetailsForCWP.setWvoClubPointCurrentYearExpiring(currentYearExpiryPoints + extendedCurrentYearBalance);
		
		log.debug("clubPointNextYearExpiring : " + nextYearExpiryPoints);
		accountDetailsForCWP.setWvoClubPointNextYearExpiring(nextYearExpiryPoints + extendedNextYearBalance);
			
		log.debug("clubPointThirdYearExpiring : " + thirdYearExpiryPoints);
		accountDetailsForCWP.setWvoClubPointThirdYearExpiring(thirdYearExpiryPoints);
		
		totalDBLClubPoints = currentYearTotalPoint + nextYearTotalPoint + thirdYearTotalPoint;
		
		if(totalDBLClubPoints < 0) {
			totalDBLClubPoints=0;
		}	
		
		log.debug("totalDBLClubPoints : " + totalDBLClubPoints);
		accountDetailsForCWP.setTotalDblPointsBalance(totalDBLClubPoints);
		
		totalClubPoints = currentYearClubPoint + nextYearClubPoint + thirdYearClubPoint;
		
		accountDetailsForCWP.setTotalClubPointsBalance(ptsMembershipDetails.getClubPoints()+totalDBLClubPoints);
		accountDetailsForCWP.setWvoClubPoints(totalClubPoints);
		
		LocalDate calStartDate = LocalDate.now();
		accountDetailsForCWP.setCurrentYearStartDate(calStartDate);
		
		LocalDate calEndDate = LocalDate.now();
		calEndDate = calEndDate.plusYears(2);
		accountDetailsForCWP.setCurrentYearEndDate(calEndDate);
		
		if(null != ptsMembershipDetails){
			accountDetailsForCWP.setExtendPoints(ptsMembershipDetails.getMaxExtendPoints());
			log.info("getMaxExtendPoints ===============: " + ptsMembershipDetails.getMaxExtendPoints());
		}
		
		if(null != accountDetailsForCWP.getCurrentYearStartDate()){
			currentYear = accountDetailsForCWP.getCurrentYearStartDate().getYear();
		}
		if(null != accountDetailsForCWP.getNextYearStartDate()){
			nextYear = accountDetailsForCWP.getNextYearStartDate().getYear();
		}
		if(null != accountDetailsForCWP.getThirdYearStartDate()){
			thirdYear = accountDetailsForCWP.getThirdYearStartDate().getYear();
		}
		
		accountDetailsForCWP.setCurrentYear(currentYear);
		accountDetailsForCWP.setNextYear(nextYear);
		accountDetailsForCWP.setThirdYear(thirdYear);
	
		totalDBLPointsCurrentYear = extendedCurrentYearBalance + savedCurrentYearBalance + 
				currentYearBalance + nextYearBalance;
		totalPointsCurrentYear = totalDBLPointsCurrentYear + ptsMembershipDetails.getClubPoints();
		
		totalDBLPointsNextYear = extendedNextYearBalance + savedNextYearBalance + 
				nextYearAvailableStandardPoints + thirdYearBalance;
		totalPointsNextYear = totalDBLPointsNextYear + ptsMembershipDetails.getClubPoints();
		
		totalDBLPointsThirdYear = savedThirdYearBalance + thirdYearBalance;
		totalPointsThirdYear = totalDBLPointsThirdYear + ptsMembershipDetails.getClubPoints();
		
		accountDetailsForCWP.setLastChancePointsCurrentYear(extendedCurrentYearBalance);
		accountDetailsForCWP.setSavedPointsCurrentYear(savedCurrentYearBalance);
		accountDetailsForCWP.setDepositedPointsCurrentYear(currentYearBalance);
		accountDetailsForCWP.setBorrowablePointsCurrentYear(nextYearBalance);
		accountDetailsForCWP.setTotalDBLPointsCurrentYear(totalDBLPointsCurrentYear);
		accountDetailsForCWP.setTotalPointsCurrentYear(totalPointsCurrentYear);
		
		if(extendedNextYearBalance == 0){
			accountDetailsForCWP.setExtendablePointsNextYear(accountDetailsForCWP.getExtendPoints());
			totalDBLPointsNextYear = (long) (accountDetailsForCWP.getExtendPoints() + extendedNextYearBalance + 
					savedNextYearBalance + nextYearBalance) + thirdYearBalance;
			totalPointsNextYear = totalDBLPointsNextYear + ptsMembershipDetails.getClubPoints();
		}
		
		accountDetailsForCWP.setLastChancePointsNextYear(extendedNextYearBalance);
		accountDetailsForCWP.setSavedPointsNextYear(savedNextYearBalance);
		accountDetailsForCWP.setDepositedPointsNextYear(nextYearBalance);
		accountDetailsForCWP.setBorrowablePointsNextYear(thirdYearBalance);
		accountDetailsForCWP.setTotalDBLPointsNextYear(totalDBLPointsNextYear);
		accountDetailsForCWP.setTotalPointsNextYear(totalPointsNextYear);
		
		accountDetailsForCWP.setSavedPointsThirdYear(savedThirdYearBalance);
		accountDetailsForCWP.setDepositedPointsThirdYear(thirdYearBalance);
		accountDetailsForCWP.setTotalDBLPointsThirdYear(totalDBLPointsThirdYear);
		accountDetailsForCWP.setTotalPointsThirdYear(totalPointsThirdYear);
	
		log.debug("Exiting from calculateCWPBalance method");
		
		return accountDetailsForCWP;
	}
}
