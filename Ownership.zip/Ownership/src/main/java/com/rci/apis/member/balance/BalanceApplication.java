package com.rci.apis.member.balance;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.cloud.openfeign.FeignFormatterRegistrar;
import org.springframework.context.annotation.Bean;
import org.springframework.format.FormatterRegistry;
import org.springframework.format.datetime.standard.DateTimeFormatterRegistrar;

import lombok.extern.slf4j.Slf4j;

/**
 * BalanceApplication class will load the end points for member balance sub-domain.
 */

@Slf4j
@SpringBootApplication(scanBasePackages={"com.rci.apis.member.balance"})
@EnableFeignClients
@EnableCaching
public class BalanceApplication {

	/**
	 * Startup method to start the Member Balance application.
	 *
	 * @param args the arguments to start the Member Balance application.
	 */
	public static void main(String[] args) {
		SpringApplication.run(BalanceApplication.class, args);
	}
	
	/**
	 * Setup method for the Member Balance application.
	 * @return CommandLineRunner
	 */
	@Bean
	public CommandLineRunner setup() {
		return (args) -> 
		log.info("Member balance application has been started successfully");
	}
	
	@Bean
	public FeignFormatterRegistrar localDateFeignFormatterRegistrar() {
	    return new FeignFormatterRegistrar() {
	        @Override
	        public void registerFormatters(FormatterRegistry formatterRegistry) {
	            DateTimeFormatterRegistrar registrar = new DateTimeFormatterRegistrar();
	            registrar.setUseIsoFormat(true);
	            registrar.registerFormatters(formatterRegistry);
	        }
	    };
	}

}

