package com.rci.apis.member.balance.service;

import java.time.LocalDate;

import com.rci.apis.member.balance.entity.AccountDetailsForClub;
import com.rci.service.common.model.ConsumerChannel;
import com.rci.service.common.model.MemberType;

/**
 * CWPAccountDetailsService interface will provide the methods for calculation of Points balance.
 * 
 */

public interface ClubAccountDetailsService {

	/**
	 * Calculates the balance information for the Member based on member Id.
	 * @param memberId  The unique id for the member
	 * @param consumerChannel  consumer Channel
	 * @param operatorId  operator Id
	 * @param startDate The start date
	 * @param membershipSubType Membership Sub Type for the member
	 * @return the AccountDetailsForClub entity for the Member based on memberId.
	 */
	
	public abstract AccountDetailsForClub calculateCWPBalance(String memberId, ConsumerChannel consumerChannel, String operatorId, LocalDate startDate,
			MemberType memberType);
	
}
