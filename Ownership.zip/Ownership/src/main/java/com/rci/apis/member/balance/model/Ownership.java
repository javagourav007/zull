package com.rci.apis.member.balance.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@ApiModel("Customer Ownership Details")
public class Ownership {
    @ApiModelProperty("Contract Number")
    private Integer contractNo;

    @ApiModelProperty("Resort Code")
    private String propertyCode;

    @ApiModelProperty("Inventory Usage Code")
    private String inventoryUsageCode;

    @ApiModelProperty("Contract Points")
    private Long contractPoints;

    @ApiModelProperty("Week Interval")
    private Integer weekInterval;

    @ApiModelProperty("Unit Number")
    private String unitNo;

    @ApiModelProperty("Unit Type")
    private String unitType;

    @ApiModelProperty("Unit Type Description of a Property")
    private String unitTypeDescription;

    @ApiModelProperty("Season")
    private String season;

    @ApiModelProperty("Home Week Indicator")
    private String homeWeekInd;

    @ApiModelProperty("Home Group Indicator")
    private String homeGroupInd;

    @ApiModelProperty("Home Resort Indicator")
    private String homeResortInd;

    @ApiModelProperty("Pure Point Indicator")
    private String purePointInd;

    @ApiModelProperty("Contract Expiration Date")
    private LocalDate contractExpDate;

    @ApiModelProperty("Affiliate Code")
    private String affiliateCode;
    
    @ApiModelProperty("Affiliate Code")
    private List<Resort> affiliatedHomeGroups;

}
