package com.rci.apis.member.balance.model;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModel;
import lombok.Data;

/**
 * Points Balance Information.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@ApiModel("Points Balance Information")
public class PointsBalance {

   private int currentYear;
   private LocalDate currentYearStartDate;
   private LocalDate currentYearEndDate;
   private long currentYearAvailablePoints;
   private long minimumExpiringPoints;
   private int daysUntilExpiration;
   private DBLPointsBreakup currentYearDBLPointsBreakup;
   
   private int nextYear;
   private LocalDate nextYearStartDate;
   private LocalDate nextYearEndDate;
   private long nextYearAvailablePoints;
   private DBLPointsBreakup nextYearDBLPointsBreakup;
   
   private int thirdYear;
   private LocalDate thirdYearStartDate;
   private LocalDate thirdYearEndDate;
   private long thirdYearAvailablePoints;
   private DBLPointsBreakup thirdYearDBLPointsBreakup;
   
   private long totalClubPoints;
   private double maxExtendPoints;
      
}

