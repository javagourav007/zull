package com.rci.apis.member.balance.proxy;

import java.time.LocalDate;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.rci.apis.member.balance.entity.SynergexMemberInfoSummary;
import com.rci.apis.member.balance.entity.SynergexMemberProfile;
import com.rci.apis.member.balance.entity.SynergexPointsInquiry;
import com.rci.apis.member.balance.entity.MemberInventoryEntity;
import com.rci.service.common.model.ConsumerChannel;
import io.swagger.annotations.ApiOperation;

/**
 * Synergex service proxy to get points balance details from synergex.
 *
 */
@Component
@FeignClient(name="synergex-gateway-service", url="${proxy.url}")
public interface SynergexServiceProxy {

	/**
	 * 
	 * @param leadId The unique identifier for the member
	 * @param operatorId Unique identifier for the Operator.
	 * @param consumerChannel The ConsumerChannel
	 * @return SynergexPointsInquiry points balance entity from synergex.
	 */
	@GetMapping("/{leadId}/points/inquiry")
	@ApiOperation(value = "getPointsInquiry", notes = "Retrieves the Member points Information depending upon the LeadId", response = SynergexPointsInquiry.class)
	public SynergexPointsInquiry getPointsInquiry(@PathVariable("leadId") String leadId,
			@RequestHeader(value = "OperatorId")@NotNull String operatorId,
			@RequestHeader(value = "ConsumerChannel")@NotNull ConsumerChannel consumerChannel,
			@RequestParam("startDate") @DateTimeFormat(iso = ISO.DATE) LocalDate startDate,
			@RequestParam("membershipType") String membershipSubType);
	/**
	 * 
	 * @param leadId The unique identifier for the member
	 * @param operatorId Unique identifier for the Operator.
	 * @param consumerChannel The ConsumerChannel
	 * @return SynergexMemberInfoSummary entity from synergex.
	 */
	@GetMapping("/{leadId}/info-summary")
	public SynergexMemberInfoSummary getMemberInfoSummary(@PathVariable("leadId") @NotNull String leadId,
			@RequestHeader(value = "OperatorId", required = false, defaultValue = "WEB00USER") @NotNull String operatorId,
			@RequestHeader(value = "ConsumerChannel")@NotNull ConsumerChannel consumerChannel);
	
	/**
	 * 
	 * @param leadId The unique identifier for the member
	 * @param operatorId Unique identifier for the Operator.
	 * @param consumerChannel The ConsumerChannel
	 * @return SynergexMemberProfile entity from synergex.
	 */
	@GetMapping("/{leadId}/member-profile")
	public SynergexMemberProfile getMemberProfile(@PathVariable("leadId") @NotNull String leadId,
			@RequestHeader(value = "OperatorId", required = false, defaultValue = "WEB00USER") @NotNull String operatorId,
			@RequestHeader(value = "ConsumerChannel")@NotNull ConsumerChannel consumerChannel);
	
	/**
	 * 
	 * @param leadId The unique identifier for the member
	 * @param operatorId Unique identifier for the Operator.
	 * @param consumerChannel The ConsumerChannel
	 * @return SynergexMemberInventories entity from synergex.
	 */
    @GetMapping("/{leadId}/points/inventories")
	public List<MemberInventoryEntity> getMemberInventory(@PathVariable("leadId") @NotNull String leadId,
                                                          @RequestHeader("OperatorId") @NotNull String operatorId,
                                                          @RequestHeader(value = "ConsumerChannel") @NotNull ConsumerChannel consumerChannel);
}
