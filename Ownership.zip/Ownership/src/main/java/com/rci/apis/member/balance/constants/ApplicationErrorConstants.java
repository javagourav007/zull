package com.rci.apis.member.balance.constants;

public class ApplicationErrorConstants {

	public static final String SERVICE = "M";
	
	/** Start: Use case specific Service identifier*/
	public static final String GET_PTS_BAL = "POGB";
	public static final String GET_PTS_OWN = "GPON";
	/** End: Use case specific Service identifier */
	
	/** Start: Use case specific Error code*/
	public static final String GENERAL_EXCEPTION = "100045";
	public static final String SERVICE_LOCATOR_EXCEPTION = "100379";
	/** End: Use case specific Error code*/
	
}
