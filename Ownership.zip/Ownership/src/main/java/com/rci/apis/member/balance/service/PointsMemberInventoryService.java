package com.rci.apis.member.balance.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rci.apis.member.balance.constants.ApplicationErrorConstants;
import com.rci.apis.member.balance.entity.MemberInventoryEntity;
import com.rci.apis.member.balance.exception.BalanceInfoException;
import com.rci.apis.member.balance.exception.PointsMemberInventoryExcecption;
import com.rci.apis.member.balance.mapper.SynMemberInventoryEntityMapper;
import com.rci.apis.member.balance.model.Ownership;
import com.rci.apis.member.balance.proxy.SynergexServiceProxy;
import com.rci.service.common.exception.BaseServiceException;
import com.rci.service.common.model.ConsumerChannel;

import feign.FeignException;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PointsMemberInventoryService {

	@Autowired
	private SynergexServiceProxy proxy;
	
	@Autowired
	private SynMemberInventoryEntityMapper mapper;
	private static final String FEIGN_EXCEPTION ="Feign Exception";
	private static final String GENERAL_EXCEPTION ="General Exception";
	
	public List<Ownership> getMemberInventory(String leadId, String operatorId, ConsumerChannel consumerChannel){
		List<Ownership> ownerships = new ArrayList<Ownership>();
		try {
		log.debug("Invoking Synergex API Gateway :{}", "GetMemberInventory");
		List<MemberInventoryEntity> inventories = proxy.getMemberInventory(leadId, operatorId, consumerChannel);
		if(CollectionUtils.isNotEmpty(inventories)) {
			if (CollectionUtils.isNotEmpty(inventories)) {
				inventories.forEach(inventory -> {
				Ownership ownership = mapper.map(inventory);
				ownerships.add(ownership);
			});
		}
		log.debug("Exiting from Synergex API Gateway :{}", "GetMemberInventory");
		
		}
		}catch (BaseServiceException e) {
			throw e;
		}catch (FeignException e) {
			throw new PointsMemberInventoryExcecption(FEIGN_EXCEPTION, ApplicationErrorConstants.SERVICE_LOCATOR_EXCEPTION, e);
		}catch (Exception e) {
			throw new PointsMemberInventoryExcecption(GENERAL_EXCEPTION, e);
		}
		return ownerships;
	}
}
