package com.rci.apis.member.balance.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class ResortEntity {
	
	@Id
	@Column(name="RESORT_ID")
	private String resortId;
	
	@Column(name="RESORT_NAME")
	private String resortName;
	
	@Column(name="AFFILIATE_CODE")
	private String affiliatedCode;
	
	
}
