package com.rci.apis.member.balance.mapper;

import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.rci.apis.member.balance.entity.AccountDetailsForClub;
import com.rci.apis.member.balance.model.DBLPointsBreakup;
import com.rci.apis.member.balance.model.PointsBalance;

import lombok.extern.slf4j.Slf4j;

/**
 * Mapper to populate PointsBalance model from SynergexPointsMembership.
 *
 */
@Component
@Slf4j
@Mapper(componentModel = "spring")
public abstract class PointsBalanceEntityMapper {

	@Value("${clubs.CWP.minimum-expiring-points}")
	private long minimumExpiringPoints;
	
	@Value("${clubs.CWP.days-until-expiration}")
	private int daysUntilExpiration;
	
	/**
	 * Mapper to populate PointsBalance model from AccountDetailsForCWP.
	 * @param source AccountDetailsForCWP entity
	 * @return PointsBalance model.
	 */
	
	@Mappings({
				@Mapping(target = "currentYear", source = "currentYear"),
				@Mapping(target = "currentYearStartDate", source = "currentYearStartDate"),
				@Mapping(target = "currentYearEndDate", source = "currentRCIYearEndDate"),
				@Mapping(target = "currentYearAvailablePoints", source = "totalPointsCurrentYear"),
				@Mapping(target = "nextYear", source = "nextYear"),
				@Mapping(target = "nextYearStartDate", source = "nextYearStartDate"),
				@Mapping(target = "nextYearEndDate", source = "nextYearEndDate"),
				@Mapping(target = "nextYearAvailablePoints", source = "totalPointsNextYear"),
				@Mapping(target = "thirdYear", source = "thirdYear"),
				@Mapping(target = "thirdYearStartDate", source = "thirdYearStartDate"),
				@Mapping(target = "thirdYearEndDate", source = "thirdYearEndDate"),
				@Mapping(target = "thirdYearAvailablePoints", source = "totalPointsThirdYear"),
				@Mapping(target = "totalClubPoints", source = "wvoClubPoints"),
				@Mapping(target = "maxExtendPoints", source = "extendPoints")
	})
	
	public abstract PointsBalance map(AccountDetailsForClub accountDetailsForCWP);
	
	/**
	 * Additional mapping for the properties in AccountDetailsForCWP entity to the PointsBalance model.
	 * @param accountDetailsForCWP AccountDetailsForCWP - Entity for fetching the account details service for CWP.
	 * @param pointsBalance PointsBalance model.
	 */
	@AfterMapping
	protected void afterMapping(AccountDetailsForClub accountDetailsForCWP, @MappingTarget PointsBalance pointsBalance) {
		
		log.debug("Enter afterMapping");
		
		DBLPointsBreakup currentYearDBLPointsBreakup = new DBLPointsBreakup();
		DBLPointsBreakup nextYearDBLPointsBreakup = new DBLPointsBreakup();
		DBLPointsBreakup thirdYearDBLPointsBreakup = new DBLPointsBreakup();
		
		if(null != accountDetailsForCWP){
			
			currentYearDBLPointsBreakup.setBorrowablePoints(accountDetailsForCWP.getBorrowablePointsCurrentYear());
			currentYearDBLPointsBreakup.setDepositedPointsThisYear(accountDetailsForCWP.getDepositedPointsCurrentYear());
			currentYearDBLPointsBreakup.setExpiringPoints(accountDetailsForCWP.getWvoClubPointCurrentYearExpiring());
			currentYearDBLPointsBreakup.setDepositedPointsLastYear(accountDetailsForCWP.getSavedPointsCurrentYear());
			currentYearDBLPointsBreakup.setLastChancePoints(accountDetailsForCWP.getLastChancePointsCurrentYear());
			currentYearDBLPointsBreakup.setTotalDBLPoints(accountDetailsForCWP.getTotalDBLPointsCurrentYear());
			
			nextYearDBLPointsBreakup.setBorrowablePoints(accountDetailsForCWP.getBorrowablePointsNextYear());
			nextYearDBLPointsBreakup.setDepositedPointsThisYear(accountDetailsForCWP.getDepositedPointsNextYear());
			nextYearDBLPointsBreakup.setExpiringPoints(accountDetailsForCWP.getWvoClubPointNextYearExpiring());
			nextYearDBLPointsBreakup.setDepositedPointsLastYear(accountDetailsForCWP.getSavedPointsNextYear());
			nextYearDBLPointsBreakup.setExtendablePoints(accountDetailsForCWP.getExtendablePointsNextYear());
			nextYearDBLPointsBreakup.setLastChancePoints(accountDetailsForCWP.getLastChancePointsNextYear());
			nextYearDBLPointsBreakup.setTotalDBLPoints(accountDetailsForCWP.getTotalDBLPointsNextYear());
			
			thirdYearDBLPointsBreakup.setDepositedPointsThisYear(accountDetailsForCWP.getDepositedPointsThirdYear());
			thirdYearDBLPointsBreakup.setExpiringPoints(accountDetailsForCWP.getWvoClubPointThirdYearExpiring());
			thirdYearDBLPointsBreakup.setDepositedPointsLastYear(accountDetailsForCWP.getSavedPointsThirdYear());
			thirdYearDBLPointsBreakup.setTotalDBLPoints(accountDetailsForCWP.getTotalDBLPointsThirdYear());
		}
		
		pointsBalance.setCurrentYearDBLPointsBreakup(currentYearDBLPointsBreakup);
		pointsBalance.setNextYearDBLPointsBreakup(nextYearDBLPointsBreakup);
		pointsBalance.setThirdYearDBLPointsBreakup(thirdYearDBLPointsBreakup);
		
		pointsBalance.setMinimumExpiringPoints(minimumExpiringPoints);
		pointsBalance.setDaysUntilExpiration(daysUntilExpiration);
		
		log.debug("Exit afterMapping");
	}
}
