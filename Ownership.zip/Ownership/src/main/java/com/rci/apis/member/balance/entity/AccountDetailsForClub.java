package com.rci.apis.member.balance.entity;

import java.io.Serializable;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@ApiModel("Account Details for Club")
public class AccountDetailsForClub implements Serializable {
	
	@ApiModelProperty(value = "The Constant serialVersionUID")
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "Current Year")
	private int currentYear;
	
	@ApiModelProperty(value = "Next Year")
	private int nextYear;
	
	@ApiModelProperty(value = "Third Year")
	private int thirdYear;
	
	@ApiModelProperty(value = "The current RCI year end date")
	private LocalDate currentRCIYearEndDate;
	
	@ApiModelProperty(value = "The next year end date")
	private LocalDate nextYearEndDate;
	
	@ApiModelProperty(value = "The third year end date")
	private LocalDate thirdYearEndDate;
	
	@ApiModelProperty(value = "The next year start date")
	private LocalDate nextYearStartDate;
	
	@ApiModelProperty(value = "The third year start date")
	private LocalDate thirdYearStartDate;
	
	@ApiModelProperty(value = "Current Year Expiring Club Points")
	private long wvoClubPointCurrentYearExpiring;
	
	@ApiModelProperty(value = "Next Year Expiring Club Points")
	private long wvoClubPointNextYearExpiring;
	
	@ApiModelProperty(value = "Third Year Expiring Club Points")
	private long wvoClubPointThirdYearExpiring;
	
	@ApiModelProperty(value = "Total DBL Points Balance")
	private long totalDblPointsBalance;
	
	@ApiModelProperty(value = "Total Club Points Balance")
	private long totalClubPointsBalance;
	
	@ApiModelProperty(value = "WVO Club Points")
	private long wvoClubPoints;
	
	@ApiModelProperty(value = "Current Year Start Date")
	private LocalDate currentYearStartDate;
	
	@ApiModelProperty(value = "Current Year End Date")
	private LocalDate currentYearEndDate;
	
	@ApiModelProperty(value = "Extend Points")
	private double extendPoints;
	
	@ApiModelProperty(value = "Last Chance Points Current Year")
	private long lastChancePointsCurrentYear;
	
	@ApiModelProperty(value = "Saved Points Current Year")
	private long savedPointsCurrentYear;
	
	@ApiModelProperty(value = "Deposited Points Current Year")
	private long depositedPointsCurrentYear;
	
	@ApiModelProperty(value = "Borrowable Points Current Year")
	private long borrowablePointsCurrentYear;
	
	@ApiModelProperty(value = "Total Points Deposit with RCI for Current Year")
	private long totalDBLPointsCurrentYear;
	
	@ApiModelProperty(value = "Current Year Available Points")
	private long totalPointsCurrentYear;
	
	@ApiModelProperty(value = "Last Chance Points Next Year")
	private long lastChancePointsNextYear;
	
	@ApiModelProperty(value = "Extendable Points Next Year")
	private double extendablePointsNextYear;
	
	@ApiModelProperty(value = "Saved Points Next Year")
	private long savedPointsNextYear;
	
	@ApiModelProperty(value = "Deposited Points Next Year")
	private long depositedPointsNextYear;
	
	@ApiModelProperty(value = "Borrowable Points Next Year")
	private long borrowablePointsNextYear;
	
	@ApiModelProperty(value = "Total Points Deposit with RCI for Next Year")
	private long totalDBLPointsNextYear;
	
	@ApiModelProperty(value = "Next Year Available Points")
	private long totalPointsNextYear;
	
	@ApiModelProperty(value = "Saved Points Third Year")
	private long savedPointsThirdYear;
	
	@ApiModelProperty(value = "Deposited Points Third Year")
	private long depositedPointsThirdYear;
	
	@ApiModelProperty(value = "Total Points Deposit with RCI for Third Year")
	private long totalDBLPointsThirdYear;
	
	@ApiModelProperty(value = "Third Year Available Points")
	private long totalPointsThirdYear;

}
