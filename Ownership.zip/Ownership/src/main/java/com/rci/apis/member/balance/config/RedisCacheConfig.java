package com.rci.apis.member.balance.config;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;

@Configuration
public class RedisCacheConfig {

	@Value("${spring.redis.cache-expire-time.cache-manager.points-balance}")
	private String pointsBalanceCacheManagerExpireTime;
	
	public static final String POINTS_BALANCE_CACHE_MANAGER = "PointsBalanceCacheManager";
	public static final String POINTS_BALANCE_CACHE = "PointsBalanceCache";
	
	@Primary  
	@Bean(name = POINTS_BALANCE_CACHE_MANAGER)
	public RedisCacheManager ptsMemberBalanceCacheManager(LettuceConnectionFactory lettuceConnectionFactory) {
		
	RedisCacheConfiguration redisCacheConfiguration = RedisCacheConfiguration.defaultCacheConfig()
			.disableCachingNullValues()
			.entryTtl(Duration.ofMinutes(Integer.parseInt(pointsBalanceCacheManagerExpireTime)));
	
	   redisCacheConfiguration.usePrefix();

	   return RedisCacheManager.RedisCacheManagerBuilder.fromConnectionFactory(lettuceConnectionFactory)
               .cacheDefaults(redisCacheConfiguration).build();
	}
}