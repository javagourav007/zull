package com.rci.apis.member.balance.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.springframework.stereotype.Component;

import com.rci.apis.member.balance.entity.PointsBalanceFromClubs;
import com.rci.apis.member.balance.model.PointsMembershipBalanceFromClubs;

/**
 * Mapper to populate PointsBalanceFromClubs entity from PointsMembershipBalanceFromClubs model.
 *
 */
@Component
@Mapper(componentModel = "spring")
public interface PointsMembershipBalanceFromClubsMapper {
	
	@Mappings({
		@Mapping(target = "memberID", source = "memberID"),
		@Mapping(target = "currentYearBalance", source = "currentYearBalance"),
		@Mapping(target = "nextYearBalance", source = "nextYearBalance"),
		@Mapping(target = "thirdYearBalance", source = "thirdYearBalance"),
		@Mapping(target = "currentYearStartDate", source = "currentYearStartDate"),
		@Mapping(target = "nextYearStartDate", source = "nextYearStartDate"),
		@Mapping(target = "thirdYearStartDate", source = "thirdYearStartDate"),
		@Mapping(target = "currentYearEndDate", source = "currentYearEndDate"),
		@Mapping(target = "nextYearEndDate", source = "nextYearEndDate"),
		@Mapping(target = "thirdYearEndDate", source = "thirdYearEndDate")
	})

	public abstract PointsBalanceFromClubs map(PointsMembershipBalanceFromClubs ptsMembershipBalanceFromClubs);

}
