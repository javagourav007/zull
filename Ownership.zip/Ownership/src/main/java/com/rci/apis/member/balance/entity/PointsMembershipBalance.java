package com.rci.apis.member.balance.entity;

import java.time.LocalDate;
import java.util.Calendar;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PointsMembershipBalance{

	/** The current year balance. */
	private long currentYearBalance;

	/** The next year balance. */
	private long nextYearBalance;

	/** The third year balance. */
	private long thirdYearBalance;

	/** The current year start date. */
	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate currentYearStartDate;

	/** The next year start date. */
	@JsonFormat(pattern="yyyy-MM-dd")
	private Calendar nextYearStartDate;

	/** The third year start date. */
	@JsonFormat(pattern="yyyy-MM-dd")
	private Calendar thirdYearStartDate;

	/** The current year end date. */
	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate currentYearEndDate;

	/** The next year end date. */
	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate nextYearEndDate;

	/** The third year end date. */
	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate thirdYearEndDate;

	/** The current use year. */
	private int currentUseYear;

	/** The next use year. */
	private int nextUseYear;

	/** The third use year. */
	private int thirdUseYear;

	/** The points membership balance. */
	private String pointsMembershipBalanceType;

	/** The points origin. */
	private String pointsOrigin;

	/** The points nature. */
	private String pointsNature;

	/** The current restricted points. */
    private long currentRestrictedPoints;

    /** The next year restricted points. */
    private long nextYearRestrictedPoints;

    /** The third year restricted points. */
    private long thirdYearRestrictedPoints;

    /** The dues balance. */
    private double duesBalance;

    /** The block indicator. */
    private String blockIndicator;

    /** The block points year indicator. */
    private String blockPointsYearIndicator;

    private long annualPointsAllotment;

    private double pointsBalance;

    private String pointsTypeDescription;
    
	private long firstYearRegPointsBalance;
	
	private long firstYearSavedPointsBalance;
	
	private long firstYearExtendedPointsBalance;
	
	private long firstYearPltExtendedPointsBalance;
	
	private long secondYearRegPointsBalance;
	
	private long secondYearSavedPointsBalance;
	
	private long secondYearExtendedPointsBalance;
	
	private long secondYearPltExtendedPointsBalance;
	
	private long thirdYearRegPointsBalance;
	
	private long thirdYearSavedPointsBalance;
	
	private long thirdYearExtendedPointsBalance;
	
	private long thirdYearPltExtendedPointsBalance;
		
	private boolean isEligibleToSave;

	private boolean borrowEligible;
	
	private LocalDate firstYearEndDate;
	
	private LocalDate secondYearEndDate;	
		
}
