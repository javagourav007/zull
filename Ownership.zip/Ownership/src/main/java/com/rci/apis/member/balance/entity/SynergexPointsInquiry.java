package com.rci.apis.member.balance.entity;

import java.time.LocalDate;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;



@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@ApiModel("Points Membership Details")
public class SynergexPointsInquiry {
	
	@ApiModelProperty(value = "The Constant serialVersionUID")
    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "If the consumer is elite member ")
    private boolean isEliteMemberFlag;
    
    @ApiModelProperty(value = "If the membership is auto renewable ")
    private boolean membersAutoRenewable;
    
    @ApiModelProperty(value = "If the member points unit is upgradable")
    private boolean unitUpgradeAllowed;
    
    @ApiModelProperty(value = "current point balance")
    @JsonIgnore
    private long currentPointsBalance;
    
    @ApiModelProperty(value = "The current restricted points")
    @JsonIgnore
    private long currentRestrictedPoints;
    
    @ApiModelProperty(value = "The current status code")
    private int currentStatusCode;
    
    @ApiModelProperty(value = "The current use end date")
    @JsonIgnore
    private LocalDate currentUseEndDate;
    
    @ApiModelProperty(value = "The current year points")
    private long currentYearAllocatedPoints;
    
    @ApiModelProperty(value = "Current year club point balance")
    @JsonIgnore
    private long currentYearClubPointsBalance;
    
    @ApiModelProperty(value = "Whether the developer paid platinum fee")
    private boolean isDeveloperPaidPlatinumFee;
    
    @ApiModelProperty(value = "Whether the developer paid platinum fee")
    private boolean isDeveloperPaidStdMembershipFee;
    
    @ApiModelProperty(value = "Whether the developer paid platinum fee")
    private boolean isDirectDebitUser;
    
    @ApiModelProperty(value = "The dues balance")
    @JsonIgnore
    private double duesBalance;
    
    @ApiModelProperty(value = "The effective date code")
    private int effectiveDateCode;
    
    @ApiModelProperty(value = "Whether eligible for standard renew")
    private boolean isEligibleForStdRenew;    
    
    @ApiModelProperty(value = "Whether extyended ponits function present")
    private boolean isExtendPointsFunctionPresent;
    
    @ApiModelProperty(value = "The interval number")
    private int intervalNumber;
    
    @ApiModelProperty(value = "The lead ID")
    private String leadID;
    
    @ApiModelProperty(value = "Maximum extendable points")
    private double maxExtendablePoints;
    
    @ApiModelProperty(value = "Whether the member is eligible to upgrade")
    private boolean isMbrEligibleToUpgradeTier;
    
    @ApiModelProperty(value = "Next year club points balance")
    @JsonIgnore
    private long nextYearClubPointsBalance;
    
    @ApiModelProperty(value = "The nexty year end date")
    @JsonIgnore
    private LocalDate nextYearEndDate;
    
    @ApiModelProperty(value = "The upcoming year points")
    @JsonIgnore
    private long nextYearPoints;
    
    @ApiModelProperty(value = "The next year restricted points")
    @JsonIgnore
    private long nextYearRestrictedPoints;
    
    @ApiModelProperty(value = "The points membership balances")
    private List<PointsMembershipBalance> pointsMembershipBalances;
    
    @ApiModelProperty(value = "The points partner used points")
    private long pointsPartnerUsedPoints;
    
    @ApiModelProperty(value = "Whether the standard renew function is present")
    private boolean isStdRenewFunctionPresent;
    
    @ApiModelProperty(value = "Third year club point balance")
    @JsonIgnore
    private long thirdYearClubPointsBalance;
    
    @ApiModelProperty(value = "The third year end date")
    @JsonIgnore
    private LocalDate thirdYearEndDate;
    
    @ApiModelProperty(value = "The third year ponits balance")
    @JsonIgnore
    private long thirdYearPoints;
    
    @ApiModelProperty(value = "The third year restricted points")
    @JsonIgnore
    private long thirdYearRestrictedPoints;
    
    @ApiModelProperty(value = "The total accelerated usage")
    private int totalAcceleratedUsage;
    
    @ApiModelProperty(value = "The total usage years")
    private int totalUsageYears;
  
    
  }
