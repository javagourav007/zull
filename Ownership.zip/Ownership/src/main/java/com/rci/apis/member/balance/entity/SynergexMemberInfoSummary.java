package com.rci.apis.member.balance.entity;
	
import lombok.Data;
import java.time.LocalDate;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Data
@ApiModel("Membership Information of cutomer")
public class SynergexMemberInfoSummary {

	@ApiModelProperty("Save Point Expiration Date")
    private LocalDate savePointExpDt;
	
	@ApiModelProperty("Save Point Used")
    private Long savePointsUsed;
	
	@ApiModelProperty("Auto Renew Flag")
    private Boolean autoRenew;

    @ApiModelProperty("Membership Paid by Developer Flag")
    private Boolean membershipPaidByDeveloper;
	
	@ApiModelProperty("Borrowable Points")
    private Long borrowablePoint;
	
	@ApiModelProperty("Borrow Eligible Flag")
    private Boolean borrowEligible;
	
	@ApiModelProperty("Current Paid Through Date")
    private LocalDate currentPtd;
	
	@ApiModelProperty("Current Use Year End Date")
    private LocalDate currentUseYearEndDate;
	
	@ApiModelProperty("Current Year")
    private Short currentYear;
	
	@ApiModelProperty("Current Year Points")
    private Long currentYearPoints;
	
	@ApiModelProperty("Eligible to Standard Renewal")
    private Boolean eligibleToStdRnwl;
	
	@ApiModelProperty("Eligible to Tier Upgrade")
    private Boolean eligibleToTierUpgrade;
	
	@ApiModelProperty("Expiring Points")
    private Long expiringPoints;
	
	@ApiModelProperty("Extend Eligible Flag")
    private Boolean extendEligible;
	
	@ApiModelProperty("Extend Points Expiration Date")
    private LocalDate extendPointsExpDate;
	
	@ApiModelProperty("First Year End Date")
    private LocalDate firstYearEndDate;
	
	@ApiModelProperty("First Year Ext Points Balance")
    private Long firstYrExtPointsBal;
	
	@ApiModelProperty("First Year Platinum Ext Points Balance")
    private Long firstYrPlatExtPntsBal;
	
	@ApiModelProperty("Second Year End Date")
    private LocalDate secondYearEndDate;
	
	@ApiModelProperty("Second Year Ext Points Balance")
    private Long secondYrExtPointsBal;
	
	@ApiModelProperty("Second Year Platinum Ext Points Balance")
    private Long secondYrPlatExtPntsBal;
	
	@ApiModelProperty("Second Year Reg Points Balance")
    private Long secondYrRegPointsBal;

	@ApiModelProperty("Second Year Borrowable Points Balance")
    private Long secondYrBorrowablePointsBal;

    @ApiModelProperty("Second Year Save Points Balance")
    private Long secondYrSavePointsBal;

	@ApiModelProperty("Maintain Fee Flag")
    private String maintFeeFlag;
	
	@ApiModelProperty("Member Tier")
    private String memberTier;
	
	@ApiModelProperty("Platinum Paid Through Date")
    private LocalDate platinumPtd;
	
	@ApiModelProperty("Last Platinum Renewal Date")
    private LocalDate lastPlatinumRenewalDate;
	
	@ApiModelProperty("Yearly Allot Points")
    private Long yearlyAllotPoints;
	
	@ApiModelProperty("First Year Reg Points Balance")
    private Long firstYrRegPointsBal;

    @ApiModelProperty("First Year Save Points Balance")
	private Long firstYrSavePointsBal;

	@ApiModelProperty("Maximum Points to Extend")
    private Long maxPointsToExtend;
	
	@ApiModelProperty("Next Year Points")
    private Long nextYearPoints;
	
	@ApiModelProperty("Third Year End Date")
    private LocalDate thirdYearEndDate;
	
	@ApiModelProperty("Third Year Points")
    private Long thirdYrPoints;
	
	@ApiModelProperty("Third Year Reg Points Balance")
    private Long thirdYrRegPointsBal;

    @ApiModelProperty("Third Year Borrowable Points Balance")
    private Long thirdYrBorrowablePointsBal;

    @ApiModelProperty("Third Year Save Points Balance")
    private Long thirdYrSavePointsBal;

    @ApiModelProperty("Second Year Expiring Points")
    private Long secondYrExpiringPoints;

    @ApiModelProperty("Third Year Expiring Points")
    private Long thirdYrExpiringPoints;

    @ApiModelProperty("First Year 2XPP Points")
    private Long firstYr2XPPPoints;

    @ApiModelProperty("Second Year 2XPP Points")
    private Long secondYr2XPPPoints;

    @ApiModelProperty("Third Year 2XPP Points")
    private Long thirdYr2XPPPoints;
    
    @ApiModelProperty("Eligible For Standard Renewal")
    private boolean eligibleForStandardRenewal;
    
    @ApiModelProperty("Eligible For Tier Upgrade")
	    private boolean eligibleForTierUpgrade; 
}
